(function(e){Object.defineProperty(e,Symbol.toStringTag,{value:`Module`});function t(e){if(e)try{var t=new URL(e);return t.protocol===`https:`||t.protocol===`http:`?e:void 0}catch{return}}function n(e){var n=[],r=function(e,r){var i=t(e);i&&!n.some(function(e){return e.url===i})&&n.push({url:i,kind:r})};for(var i of e.attachments??[]){var a=i.content_type??i.contentType??``,o=i.url??i.proxy_url??i.proxyURL;(a.startsWith(`image/`)||/\.(png|jpe?g|gif|webp|avif)(?:[?#]|$)/i.test(o??``))&&r(o,`image`)}for(var s of e.embeds??[])s.type===`gifv`&&s.video?r(s.video.url??s.video.proxy_url??s.video.proxyURL,`video`):s.image?r(s.image.proxy_url??s.image.proxyURL??s.image.url,`image`):s.type===`image`&&r(s.thumbnail?.proxy_url??s.thumbnail?.proxyURL??s.thumbnail?.url??s.url,`image`);return n}function r(e){if(e.referenced_message)return e.referenced_message;var t=e.referencedMessage;return t&&(`message`in t?t.message:t)}function i(e,t){return t&&e.trim()?`"${e}"`:e}function a(e,t){var r=e.content??``;if(!t.length)return r;var i=function(e){try{var t=new URL(e);if([`cdn.discordapp.com`,`media.discordapp.net`].includes(t.hostname)&&t.pathname.startsWith(`/attachments/`))return t.pathname}catch{}return e},a=t.map(function(e){return e.url});for(var o of e.attachments??[])if(n({attachments:[o]}).length)for(var s of[o.url,o.proxy_url,o.proxyURL])s&&a.push(s);for(var c of e.embeds??[])c.url&&n({embeds:[c]}).length&&a.push(c.url);return a.some(function(e){return i(e)===i(r.trim())})?``:r}var o={width:1200,height:600,quoteAreaWidth:520,quoteAreaX:640,maxContentHeight:480},s={initial:42,minimum:18,decrement:2,lineHeightMultiplier:1.25,authorMultiplier:.6,usernameMultiplier:.45,authorMinimum:22,usernameMinimum:18,watermark:18},c={authorTop:60,username:10,gradientWidth:400,watermarkPadding:20};function l(e){return e?String(e).replace(/\r\n?/g,`
`).split(`
`).map(function(e){return e.replace(/[^\S\n]+/g,` `).trim()}).join(`
`).trim():``}function u(e){if(!e||typeof e!=`string`)return``;try{var t=new URL(e);return t.searchParams.set(`size`,`512`),(t.hostname===`cdn.discordapp.com`||t.hostname===`media.discordapp.net`)&&(t.pathname=t.pathname.replace(/\.(webp|gif|jpg|jpeg)$/i,`.png`),t.searchParams.set(`format`,`png`)),t.toString()}catch{return e}}function d(e){var t=String(e??``).replace(/<a?:(\w+):(\d+)>/g,``),n=t.match(/<@!?\d+>/g);if(!n)return l(t);for(var r of n){var i=r.replace(/[<@!>]/g,``),a=valenced.discord.flux.Stores.UserStore.getUser(i);a?.username&&(t=t.replace(r,`@${a.username}`))}return l(t)}function f(e){var t=r(e);if(t)return t;var n=e.messageReference??e.message_reference;if(n){var i=valenced.discord.flux.Stores.ReferencedMessageStore.getMessageByReference(n)?.message;if(i)return i;var a=`messageId`in n?n.messageId??n.message_id:n.message_id,o=`channelId`in n?n.channelId??n.channel_id:n.channel_id,s=valenced.discord.flux.Stores.MessageStore;return typeof a==`string`&&typeof o==`string`?s.getMessage(o,a):void 0}}function p(e){return e?.author??{}}function m(e){return e?.globalName||e?.global_name||e?.username||`Unknown`}function h(e){return String(e?.username||`unknown`).replace(/[^\w.-]/g,``).slice(0,32)||`unknown`}function g(e){try{if(typeof e?.getAvatarURL==`function`)return u(e.getAvatarURL())}catch{}try{var[t]=valenced.modules.finders.lookupModule(valenced.modules.finders.filters.withProps(`getUserAvatarURL`));if(typeof t?.getUserAvatarURL==`function`)return u(t.getUserAvatarURL(e,!1))}catch{}return e?.id&&e?.avatar?`https://cdn.discordapp.com/avatars/${e.id}/${e.avatar}.png?size=512`:`https://cdn.discordapp.com/embed/avatars/0.png?size=512`}function _(e){return e?.channel_id||e?.channelId||e?.channel?.id||null}function v(e){return`${(d(e?.content||``).split(` `).filter(Boolean).slice(0,6).join(` `)||`quote`).replace(/[^\w.-]/g,`_`).slice(0,48)}-${h(p(e))}.png`}function y(e){var t=e.timestamp,n=t&&typeof t==`object`&&`toDate`in t?t.toDate():new Date(t??``);return Number.isNaN(n.getTime())?``:n.toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`,hour12:!1})}function b(e,t,r=!1){var l=p(e),u=t.allowReplies&&r?f(e):void 0,_=u&&p(u),v=u&&t.allowMedia?n(u):[],b=t.allowMedia?n(e):[],x=d(a(e,b));return{media:b,reply:u&&_?{media:v,timestamp:y(u),text:d(a(u,v))||(v.length?``:n(u).length?`[Media]`:`[Message]`),displayName:u.nick||m(_),avatarUrl:g(_),color:/^#[\da-f]{6}$/i.test(u.colorString??_.colorString??``)?u.colorString??_.colorString:`#b5bac1`}:void 0,quote:i(x,t.quotationMarks)||` `,displayName:(e.nick||m(l)).slice(0,64),authorColor:/^#[\da-f]{6}$/i.test(e.colorString??``)?e.colorString:`#f2f3f5`,isBot:!!l.bot,timestamp:y(e),username:`@${h(l)}`,avatarUrl:g(l),grayscale:!!t.grayscale,showWatermark:!!t.showWatermark,watermark:String(t.watermark||``).slice(0,32),quoteFont:`M PLUS Rounded 1c`,canvas:o,fonts:s,spacing:c}}var x=`/*
The MIT License (MIT)
Copyright (c) 2017 Matt DesLauriers

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
OR OTHER DEALINGS IN THE SOFTWARE.


*/
const GIF = (() => { const module = { exports: {} }; const exports = module.exports;
var __defProp = Object.defineProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", {value: true});
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, {get: all[name], enumerable: true});
};

// src/index.js
__markAsModule(exports);
__export(exports, {
  GIFEncoder: () => GIFEncoder,
  applyPalette: () => applyPalette,
  default: () => src_default,
  nearestColor: () => nearestColor,
  nearestColorIndex: () => nearestColorIndex,
  nearestColorIndexWithDistance: () => nearestColorIndexWithDistance,
  prequantize: () => prequantize,
  quantize: () => quantize,
  snapColorsToPalette: () => snapColorsToPalette
});

// src/constants.js
var constants_default = {
  signature: "GIF",
  version: "89a",
  trailer: 59,
  extensionIntroducer: 33,
  applicationExtensionLabel: 255,
  graphicControlExtensionLabel: 249,
  imageSeparator: 44,
  signatureSize: 3,
  versionSize: 3,
  globalColorTableFlagMask: 128,
  colorResolutionMask: 112,
  sortFlagMask: 8,
  globalColorTableSizeMask: 7,
  applicationIdentifierSize: 8,
  applicationAuthCodeSize: 3,
  disposalMethodMask: 28,
  userInputFlagMask: 2,
  transparentColorFlagMask: 1,
  localColorTableFlagMask: 128,
  interlaceFlagMask: 64,
  idSortFlagMask: 32,
  localColorTableSizeMask: 7
};

// src/stream.js
function createStream(initialCapacity = 256) {
  let cursor = 0;
  let contents = new Uint8Array(initialCapacity);
  return {
    get buffer() {
      return contents.buffer;
    },
    reset() {
      cursor = 0;
    },
    bytesView() {
      return contents.subarray(0, cursor);
    },
    bytes() {
      return contents.slice(0, cursor);
    },
    writeByte(byte) {
      expand(cursor + 1);
      contents[cursor] = byte;
      cursor++;
    },
    writeBytes(data, offset = 0, byteLength = data.length) {
      expand(cursor + byteLength);
      for (let i = 0; i < byteLength; i++) {
        contents[cursor++] = data[i + offset];
      }
    },
    writeBytesView(data, offset = 0, byteLength = data.byteLength) {
      expand(cursor + byteLength);
      contents.set(data.subarray(offset, offset + byteLength), cursor);
      cursor += byteLength;
    }
  };
  function expand(newCapacity) {
    var prevCapacity = contents.length;
    if (prevCapacity >= newCapacity)
      return;
    var CAPACITY_DOUBLING_MAX = 1024 * 1024;
    newCapacity = Math.max(newCapacity, prevCapacity * (prevCapacity < CAPACITY_DOUBLING_MAX ? 2 : 1.125) >>> 0);
    if (prevCapacity != 0)
      newCapacity = Math.max(newCapacity, 256);
    const oldContents = contents;
    contents = new Uint8Array(newCapacity);
    if (cursor > 0)
      contents.set(oldContents.subarray(0, cursor), 0);
  }
}

// src/lzwEncode.js
var BITS = 12;
var DEFAULT_HSIZE = 5003;
var MASKS = [
  0,
  1,
  3,
  7,
  15,
  31,
  63,
  127,
  255,
  511,
  1023,
  2047,
  4095,
  8191,
  16383,
  32767,
  65535
];
function lzwEncode(width, height, pixels, colorDepth, outStream = createStream(512), accum = new Uint8Array(256), htab = new Int32Array(DEFAULT_HSIZE), codetab = new Int32Array(DEFAULT_HSIZE)) {
  const hsize = htab.length;
  const initCodeSize = Math.max(2, colorDepth);
  accum.fill(0);
  codetab.fill(0);
  htab.fill(-1);
  let cur_accum = 0;
  let cur_bits = 0;
  const init_bits = initCodeSize + 1;
  const g_init_bits = init_bits;
  let clear_flg = false;
  let n_bits = g_init_bits;
  let maxcode = (1 << n_bits) - 1;
  const ClearCode = 1 << init_bits - 1;
  const EOFCode = ClearCode + 1;
  let free_ent = ClearCode + 2;
  let a_count = 0;
  let ent = pixels[0];
  let hshift = 0;
  for (let fcode = hsize; fcode < 65536; fcode *= 2) {
    ++hshift;
  }
  hshift = 8 - hshift;
  outStream.writeByte(initCodeSize);
  output(ClearCode);
  const length = pixels.length;
  for (let idx = 1; idx < length; idx++) {
    next_block: {
      const c = pixels[idx];
      const fcode = (c << BITS) + ent;
      let i = c << hshift ^ ent;
      if (htab[i] === fcode) {
        ent = codetab[i];
        break next_block;
      }
      const disp = i === 0 ? 1 : hsize - i;
      while (htab[i] >= 0) {
        i -= disp;
        if (i < 0)
          i += hsize;
        if (htab[i] === fcode) {
          ent = codetab[i];
          break next_block;
        }
      }
      output(ent);
      ent = c;
      if (free_ent < 1 << BITS) {
        codetab[i] = free_ent++;
        htab[i] = fcode;
      } else {
        htab.fill(-1);
        free_ent = ClearCode + 2;
        clear_flg = true;
        output(ClearCode);
      }
    }
  }
  output(ent);
  output(EOFCode);
  outStream.writeByte(0);
  return outStream.bytesView();
  function output(code) {
    cur_accum &= MASKS[cur_bits];
    if (cur_bits > 0)
      cur_accum |= code << cur_bits;
    else
      cur_accum = code;
    cur_bits += n_bits;
    while (cur_bits >= 8) {
      accum[a_count++] = cur_accum & 255;
      if (a_count >= 254) {
        outStream.writeByte(a_count);
        outStream.writeBytesView(accum, 0, a_count);
        a_count = 0;
      }
      cur_accum >>= 8;
      cur_bits -= 8;
    }
    if (free_ent > maxcode || clear_flg) {
      if (clear_flg) {
        n_bits = g_init_bits;
        maxcode = (1 << n_bits) - 1;
        clear_flg = false;
      } else {
        ++n_bits;
        maxcode = n_bits === BITS ? 1 << n_bits : (1 << n_bits) - 1;
      }
    }
    if (code == EOFCode) {
      while (cur_bits > 0) {
        accum[a_count++] = cur_accum & 255;
        if (a_count >= 254) {
          outStream.writeByte(a_count);
          outStream.writeBytesView(accum, 0, a_count);
          a_count = 0;
        }
        cur_accum >>= 8;
        cur_bits -= 8;
      }
      if (a_count > 0) {
        outStream.writeByte(a_count);
        outStream.writeBytesView(accum, 0, a_count);
        a_count = 0;
      }
    }
  }
}
var lzwEncode_default = lzwEncode;

// src/rgb-packing.js
function rgb888_to_rgb565(r, g, b) {
  return r << 8 & 63488 | g << 2 & 992 | b >> 3;
}
function rgba8888_to_rgba4444(r, g, b, a) {
  return r >> 4 | g & 240 | (b & 240) << 4 | (a & 240) << 8;
}
function rgb888_to_rgb444(r, g, b) {
  return r >> 4 << 8 | g & 240 | b >> 4;
}

// src/pnnquant2.js
function clamp(value, min, max) {
  return value < min ? min : value > max ? max : value;
}
function sqr(value) {
  return value * value;
}
function find_nn(bins, idx, hasAlpha) {
  var nn = 0;
  var err = 1e100;
  const bin1 = bins[idx];
  const n1 = bin1.cnt;
  const wa = bin1.ac;
  const wr = bin1.rc;
  const wg = bin1.gc;
  const wb = bin1.bc;
  for (var i = bin1.fw; i != 0; i = bins[i].fw) {
    const bin = bins[i];
    const n2 = bin.cnt;
    const nerr2 = n1 * n2 / (n1 + n2);
    if (nerr2 >= err)
      continue;
    var nerr = 0;
    if (hasAlpha) {
      nerr += nerr2 * sqr(bin.ac - wa);
      if (nerr >= err)
        continue;
    }
    nerr += nerr2 * sqr(bin.rc - wr);
    if (nerr >= err)
      continue;
    nerr += nerr2 * sqr(bin.gc - wg);
    if (nerr >= err)
      continue;
    nerr += nerr2 * sqr(bin.bc - wb);
    if (nerr >= err)
      continue;
    err = nerr;
    nn = i;
  }
  bin1.err = err;
  bin1.nn = nn;
}
function create_bin() {
  return {
    ac: 0,
    rc: 0,
    gc: 0,
    bc: 0,
    cnt: 0,
    nn: 0,
    fw: 0,
    bk: 0,
    tm: 0,
    mtm: 0,
    err: 0
  };
}
function create_bin_list(data, format) {
  const bincount = format === "rgb444" ? 4096 : 65536;
  const bins = new Array(bincount);
  const size = data.length;
  if (format === "rgba4444") {
    for (let i = 0; i < size; ++i) {
      const color = data[i];
      const a = color >> 24 & 255;
      const b = color >> 16 & 255;
      const g = color >> 8 & 255;
      const r = color & 255;
      const index = rgba8888_to_rgba4444(r, g, b, a);
      let bin = index in bins ? bins[index] : bins[index] = create_bin();
      bin.rc += r;
      bin.gc += g;
      bin.bc += b;
      bin.ac += a;
      bin.cnt++;
    }
  } else if (format === "rgb444") {
    for (let i = 0; i < size; ++i) {
      const color = data[i];
      const b = color >> 16 & 255;
      const g = color >> 8 & 255;
      const r = color & 255;
      const index = rgb888_to_rgb444(r, g, b);
      let bin = index in bins ? bins[index] : bins[index] = create_bin();
      bin.rc += r;
      bin.gc += g;
      bin.bc += b;
      bin.cnt++;
    }
  } else {
    for (let i = 0; i < size; ++i) {
      const color = data[i];
      const b = color >> 16 & 255;
      const g = color >> 8 & 255;
      const r = color & 255;
      const index = rgb888_to_rgb565(r, g, b);
      let bin = index in bins ? bins[index] : bins[index] = create_bin();
      bin.rc += r;
      bin.gc += g;
      bin.bc += b;
      bin.cnt++;
    }
  }
  return bins;
}
function quantize(rgba, maxColors, opts = {}) {
  const {
    format = "rgb565",
    clearAlpha = true,
    clearAlphaColor = 0,
    clearAlphaThreshold = 0,
    oneBitAlpha = false
  } = opts;
  if (!rgba || !rgba.buffer) {
    throw new Error("quantize() expected RGBA Uint8Array data");
  }
  if (!(rgba instanceof Uint8Array) && !(rgba instanceof Uint8ClampedArray)) {
    throw new Error("quantize() expected RGBA Uint8Array data");
  }
  const data = new Uint32Array(rgba.buffer);
  let useSqrt = opts.useSqrt !== false;
  const hasAlpha = format === "rgba4444";
  const bins = create_bin_list(data, format);
  const bincount = bins.length;
  const bincountMinusOne = bincount - 1;
  const heap = new Uint32Array(bincount + 1);
  var maxbins = 0;
  for (var i = 0; i < bincount; ++i) {
    const bin = bins[i];
    if (bin != null) {
      var d = 1 / bin.cnt;
      if (hasAlpha)
        bin.ac *= d;
      bin.rc *= d;
      bin.gc *= d;
      bin.bc *= d;
      bins[maxbins++] = bin;
    }
  }
  if (sqr(maxColors) / maxbins < 0.022) {
    useSqrt = false;
  }
  var i = 0;
  for (; i < maxbins - 1; ++i) {
    bins[i].fw = i + 1;
    bins[i + 1].bk = i;
    if (useSqrt)
      bins[i].cnt = Math.sqrt(bins[i].cnt);
  }
  if (useSqrt)
    bins[i].cnt = Math.sqrt(bins[i].cnt);
  var h, l, l2;
  for (i = 0; i < maxbins; ++i) {
    find_nn(bins, i, false);
    var err = bins[i].err;
    for (l = ++heap[0]; l > 1; l = l2) {
      l2 = l >> 1;
      if (bins[h = heap[l2]].err <= err)
        break;
      heap[l] = h;
    }
    heap[l] = i;
  }
  var extbins = maxbins - maxColors;
  for (i = 0; i < extbins; ) {
    var tb;
    for (; ; ) {
      var b1 = heap[1];
      tb = bins[b1];
      if (tb.tm >= tb.mtm && bins[tb.nn].mtm <= tb.tm)
        break;
      if (tb.mtm == bincountMinusOne)
        b1 = heap[1] = heap[heap[0]--];
      else {
        find_nn(bins, b1, false);
        tb.tm = i;
      }
      var err = bins[b1].err;
      for (l = 1; (l2 = l + l) <= heap[0]; l = l2) {
        if (l2 < heap[0] && bins[heap[l2]].err > bins[heap[l2 + 1]].err)
          l2++;
        if (err <= bins[h = heap[l2]].err)
          break;
        heap[l] = h;
      }
      heap[l] = b1;
    }
    var nb = bins[tb.nn];
    var n1 = tb.cnt;
    var n2 = nb.cnt;
    var d = 1 / (n1 + n2);
    if (hasAlpha)
      tb.ac = d * (n1 * tb.ac + n2 * nb.ac);
    tb.rc = d * (n1 * tb.rc + n2 * nb.rc);
    tb.gc = d * (n1 * tb.gc + n2 * nb.gc);
    tb.bc = d * (n1 * tb.bc + n2 * nb.bc);
    tb.cnt += nb.cnt;
    tb.mtm = ++i;
    bins[nb.bk].fw = nb.fw;
    bins[nb.fw].bk = nb.bk;
    nb.mtm = bincountMinusOne;
  }
  let palette = [];
  var k = 0;
  for (i = 0; ; ++k) {
    let r = clamp(Math.round(bins[i].rc), 0, 255);
    let g = clamp(Math.round(bins[i].gc), 0, 255);
    let b = clamp(Math.round(bins[i].bc), 0, 255);
    let a = 255;
    if (hasAlpha) {
      a = clamp(Math.round(bins[i].ac), 0, 255);
      if (oneBitAlpha) {
        const threshold = typeof oneBitAlpha === "number" ? oneBitAlpha : 127;
        a = a <= threshold ? 0 : 255;
      }
      if (clearAlpha && a <= clearAlphaThreshold) {
        r = g = b = clearAlphaColor;
        a = 0;
      }
    }
    const color = hasAlpha ? [r, g, b, a] : [r, g, b];
    const exists = existsInPalette(palette, color);
    if (!exists)
      palette.push(color);
    if ((i = bins[i].fw) == 0)
      break;
  }
  return palette;
}
function existsInPalette(palette, color) {
  for (let i = 0; i < palette.length; i++) {
    const p = palette[i];
    let matchesRGB = p[0] === color[0] && p[1] === color[1] && p[2] === color[2];
    let matchesAlpha = p.length >= 4 && color.length >= 4 ? p[3] === color[3] : true;
    if (matchesRGB && matchesAlpha)
      return true;
  }
  return false;
}

// src/color.js
function euclideanDistanceSquared(a, b) {
  var sum = 0;
  var n;
  for (n = 0; n < a.length; n++) {
    const dx = a[n] - b[n];
    sum += dx * dx;
  }
  return sum;
}

// src/palettize.js
function roundStep(byte, step) {
  return step > 1 ? Math.round(byte / step) * step : byte;
}
function prequantize(rgba, {roundRGB = 5, roundAlpha = 10, oneBitAlpha = null} = {}) {
  const data = new Uint32Array(rgba.buffer);
  for (let i = 0; i < data.length; i++) {
    const color = data[i];
    let a = color >> 24 & 255;
    let b = color >> 16 & 255;
    let g = color >> 8 & 255;
    let r = color & 255;
    a = roundStep(a, roundAlpha);
    if (oneBitAlpha) {
      const threshold = typeof oneBitAlpha === "number" ? oneBitAlpha : 127;
      a = a <= threshold ? 0 : 255;
    }
    r = roundStep(r, roundRGB);
    g = roundStep(g, roundRGB);
    b = roundStep(b, roundRGB);
    data[i] = a << 24 | b << 16 | g << 8 | r << 0;
  }
}
function applyPalette(rgba, palette, format = "rgb565") {
  if (!rgba || !rgba.buffer) {
    throw new Error("quantize() expected RGBA Uint8Array data");
  }
  if (!(rgba instanceof Uint8Array) && !(rgba instanceof Uint8ClampedArray)) {
    throw new Error("quantize() expected RGBA Uint8Array data");
  }
  if (palette.length > 256) {
    throw new Error("applyPalette() only works with 256 colors or less");
  }
  const data = new Uint32Array(rgba.buffer);
  const length = data.length;
  const bincount = format === "rgb444" ? 4096 : 65536;
  const index = new Uint8Array(length);
  const cache = new Array(bincount);
  const hasAlpha = format === "rgba4444";
  if (format === "rgba4444") {
    for (let i = 0; i < length; i++) {
      const color = data[i];
      const a = color >> 24 & 255;
      const b = color >> 16 & 255;
      const g = color >> 8 & 255;
      const r = color & 255;
      const key = rgba8888_to_rgba4444(r, g, b, a);
      const idx = key in cache ? cache[key] : cache[key] = nearestColorIndexRGBA(r, g, b, a, palette);
      index[i] = idx;
    }
  } else {
    const rgb888_to_key = format === "rgb444" ? rgb888_to_rgb444 : rgb888_to_rgb565;
    for (let i = 0; i < length; i++) {
      const color = data[i];
      const b = color >> 16 & 255;
      const g = color >> 8 & 255;
      const r = color & 255;
      const key = rgb888_to_key(r, g, b);
      const idx = key in cache ? cache[key] : cache[key] = nearestColorIndexRGB(r, g, b, palette);
      index[i] = idx;
    }
  }
  return index;
}
function nearestColorIndexRGBA(r, g, b, a, palette) {
  let k = 0;
  let mindist = 1e100;
  for (let i = 0; i < palette.length; i++) {
    const px2 = palette[i];
    const a2 = px2[3];
    let curdist = sqr2(a2 - a);
    if (curdist > mindist)
      continue;
    const r2 = px2[0];
    curdist += sqr2(r2 - r);
    if (curdist > mindist)
      continue;
    const g2 = px2[1];
    curdist += sqr2(g2 - g);
    if (curdist > mindist)
      continue;
    const b2 = px2[2];
    curdist += sqr2(b2 - b);
    if (curdist > mindist)
      continue;
    mindist = curdist;
    k = i;
  }
  return k;
}
function nearestColorIndexRGB(r, g, b, palette) {
  let k = 0;
  let mindist = 1e100;
  for (let i = 0; i < palette.length; i++) {
    const px2 = palette[i];
    const r2 = px2[0];
    let curdist = sqr2(r2 - r);
    if (curdist > mindist)
      continue;
    const g2 = px2[1];
    curdist += sqr2(g2 - g);
    if (curdist > mindist)
      continue;
    const b2 = px2[2];
    curdist += sqr2(b2 - b);
    if (curdist > mindist)
      continue;
    mindist = curdist;
    k = i;
  }
  return k;
}
function snapColorsToPalette(palette, knownColors, threshold = 5) {
  if (!palette.length || !knownColors.length)
    return;
  const paletteRGB = palette.map((p) => p.slice(0, 3));
  const thresholdSq = threshold * threshold;
  const dim = palette[0].length;
  for (let i = 0; i < knownColors.length; i++) {
    let color = knownColors[i];
    if (color.length < dim) {
      color = [color[0], color[1], color[2], 255];
    } else if (color.length > dim) {
      color = color.slice(0, 3);
    } else {
      color = color.slice();
    }
    const r = nearestColorIndexWithDistance(paletteRGB, color.slice(0, 3), euclideanDistanceSquared);
    const idx = r[0];
    const distanceSq = r[1];
    if (distanceSq > 0 && distanceSq <= thresholdSq) {
      palette[idx] = color;
    }
  }
}
function sqr2(a) {
  return a * a;
}
function nearestColorIndex(colors, pixel, distanceFn = euclideanDistanceSquared) {
  let minDist = Infinity;
  let minDistIndex = -1;
  for (let j = 0; j < colors.length; j++) {
    const paletteColor = colors[j];
    const dist = distanceFn(pixel, paletteColor);
    if (dist < minDist) {
      minDist = dist;
      minDistIndex = j;
    }
  }
  return minDistIndex;
}
function nearestColorIndexWithDistance(colors, pixel, distanceFn = euclideanDistanceSquared) {
  let minDist = Infinity;
  let minDistIndex = -1;
  for (let j = 0; j < colors.length; j++) {
    const paletteColor = colors[j];
    const dist = distanceFn(pixel, paletteColor);
    if (dist < minDist) {
      minDist = dist;
      minDistIndex = j;
    }
  }
  return [minDistIndex, minDist];
}
function nearestColor(colors, pixel, distanceFn = euclideanDistanceSquared) {
  return colors[nearestColorIndex(colors, pixel, distanceFn)];
}

// src/index.js
function GIFEncoder(opt = {}) {
  const {initialCapacity = 4096, auto = true} = opt;
  const stream = createStream(initialCapacity);
  const HSIZE = 5003;
  const accum = new Uint8Array(256);
  const htab = new Int32Array(HSIZE);
  const codetab = new Int32Array(HSIZE);
  let hasInit = false;
  return {
    reset() {
      stream.reset();
      hasInit = false;
    },
    finish() {
      stream.writeByte(constants_default.trailer);
    },
    bytes() {
      return stream.bytes();
    },
    bytesView() {
      return stream.bytesView();
    },
    get buffer() {
      return stream.buffer;
    },
    get stream() {
      return stream;
    },
    writeHeader,
    writeFrame(index, width, height, opts = {}) {
      const {
        transparent = false,
        transparentIndex = 0,
        delay = 0,
        palette = null,
        repeat = 0,
        colorDepth = 8,
        dispose = -1,
        x = 0,
        y = 0
      } = opts;
      let first = false;
      if (auto) {
        if (!hasInit) {
          first = true;
          writeHeader();
          hasInit = true;
        }
      } else {
        first = Boolean(opts.first);
      }
      width = Math.max(0, Math.floor(width));
      height = Math.max(0, Math.floor(height));
      if (first) {
        if (!palette) {
          throw new Error("First frame must include a { palette } option");
        }
        encodeLogicalScreenDescriptor(stream, width, height, palette, colorDepth);
        encodeColorTable(stream, palette);
        if (repeat >= 0) {
          encodeNetscapeExt(stream, repeat);
        }
      }
      const delayTime = Math.round(delay / 10);
      encodeGraphicControlExt(stream, dispose, delayTime, transparent, transparentIndex);
      const useLocalColorTable = Boolean(palette) && !first;
      encodeImageDescriptor(stream, width, height, useLocalColorTable ? palette : null, x, y);
      if (useLocalColorTable)
        encodeColorTable(stream, palette);
      encodePixels(stream, index, width, height, colorDepth, accum, htab, codetab);
    }
  };
  function writeHeader() {
    writeUTFBytes(stream, "GIF89a");
  }
}
function encodeGraphicControlExt(stream, dispose, delay, transparent, transparentIndex) {
  stream.writeByte(33);
  stream.writeByte(249);
  stream.writeByte(4);
  if (transparentIndex < 0) {
    transparentIndex = 0;
    transparent = false;
  }
  var transp, disp;
  if (!transparent) {
    transp = 0;
    disp = 0;
  } else {
    transp = 1;
    disp = 2;
  }
  if (dispose >= 0) {
    disp = dispose & 7;
  }
  disp <<= 2;
  const userInput = 0;
  stream.writeByte(0 | disp | userInput | transp);
  writeUInt16(stream, delay);
  stream.writeByte(transparentIndex || 0);
  stream.writeByte(0);
}
function encodeLogicalScreenDescriptor(stream, width, height, palette, colorDepth = 8) {
  const globalColorTableFlag = 1;
  const sortFlag = 0;
  const globalColorTableSize = colorTableSize(palette.length) - 1;
  const fields = globalColorTableFlag << 7 | colorDepth - 1 << 4 | sortFlag << 3 | globalColorTableSize;
  const backgroundColorIndex = 0;
  const pixelAspectRatio = 0;
  writeUInt16(stream, width);
  writeUInt16(stream, height);
  stream.writeBytes([fields, backgroundColorIndex, pixelAspectRatio]);
}
function encodeNetscapeExt(stream, repeat) {
  stream.writeByte(33);
  stream.writeByte(255);
  stream.writeByte(11);
  writeUTFBytes(stream, "NETSCAPE2.0");
  stream.writeByte(3);
  stream.writeByte(1);
  writeUInt16(stream, repeat);
  stream.writeByte(0);
}
function encodeColorTable(stream, palette) {
  const colorTableLength = 1 << colorTableSize(palette.length);
  for (let i = 0; i < colorTableLength; i++) {
    let color = [0, 0, 0];
    if (i < palette.length) {
      color = palette[i];
    }
    stream.writeByte(color[0]);
    stream.writeByte(color[1]);
    stream.writeByte(color[2]);
  }
}
function encodeImageDescriptor(stream, width, height, localPalette, x, y) {
  stream.writeByte(44);
  writeUInt16(stream, x);
  writeUInt16(stream, y);
  writeUInt16(stream, width);
  writeUInt16(stream, height);
  if (localPalette) {
    const interlace = 0;
    const sorted = 0;
    const palSize = colorTableSize(localPalette.length) - 1;
    stream.writeByte(128 | interlace | sorted | 0 | palSize);
  } else {
    stream.writeByte(0);
  }
}
function encodePixels(stream, index, width, height, colorDepth = 8, accum, htab, codetab) {
  lzwEncode_default(width, height, index, colorDepth, stream, accum, htab, codetab);
}
function writeUInt16(stream, short) {
  stream.writeByte(short & 255);
  stream.writeByte(short >> 8 & 255);
}
function writeUTFBytes(stream, text) {
  for (var i = 0; i < text.length; i++) {
    stream.writeByte(text.charCodeAt(i));
  }
}
function colorTableSize(length) {
  return Math.max(Math.ceil(Math.log2(length)), 1);
}
var src_default = GIFEncoder;

return module.exports; })();`,S=`
async function fetchMedia(url) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 20000);
    try {
        const response = await fetch(url, { signal: controller.signal });
        if (!response.ok) throw new Error("Could not download quote media.");
        const blob = await response.blob();
        if (blob.size > 30 * 1024 * 1024) throw new Error("This media is too large to quote (30 MB maximum).");
        return blob;
    } finally { clearTimeout(timer); }
}
function mediaEvent(target, event, action) {
    return new Promise((resolve, reject) => {
        const timer = setTimeout(() => finish(new Error("Media decoding timed out.")), 15000);
        const success = () => finish();
        const error = () => finish(new Error("Could not decode quote media."));
        function finish(failure) {
            clearTimeout(timer);
            target.removeEventListener(event, success);
            target.removeEventListener('error', error);
            failure ? reject(failure) : resolve();
        }
        target.addEventListener(event, success, { once: true });
        target.addEventListener('error', error, { once: true });
        action();
    });
}
async function loadMedia(item) {
    const blob = await fetchMedia(item.url);
    if (item.kind === 'video') {
        const url = URL.createObjectURL(blob);
        const video = document.createElement('video');
        video.muted = true;
        video.preload = 'auto';
        video.playsInline = true;
        try {
            await mediaEvent(video, 'loadeddata', () => { video.src = url; video.load(); });
            const duration = video.duration * 1000;
            if (!Number.isFinite(duration) || duration <= 0 || duration > 30000) throw new Error("Animated quotes support clips up to 30 seconds.");
            return {
                width: video.videoWidth, height: video.videoHeight, duration,
                boundaries: Array.from({ length: Math.ceil(duration / 50) }, (_, i) => i * 50),
                async frameAt(time) {
                    const target = Math.min((time % duration) / 1000, video.duration - 0.001);
                    if (Math.abs(video.currentTime - target) > 0.001) await mediaEvent(video, 'seeked', () => { video.currentTime = target; });
                    return { image: video, close() {} };
                },
                close() { video.removeAttribute('src'); video.load(); URL.revokeObjectURL(url); },
            };
        } catch (error) { video.removeAttribute('src'); video.load(); URL.revokeObjectURL(url); throw error; }
    }
    const bytes = await blob.arrayBuffer();
    const signature = new Uint8Array(bytes, 0, Math.min(bytes.byteLength, 12));
    const type = signature[0] === 71 && signature[1] === 73 && signature[2] === 70 ? 'image/gif'
        : signature[0] === 82 && signature[8] === 87 ? 'image/webp'
        : blob.type.split(';')[0];
    if (typeof ImageDecoder !== 'undefined' && await ImageDecoder.isTypeSupported(type)) {
        const decoder = new ImageDecoder({ data: bytes, type, preferAnimation: true });
        try {
            await decoder.tracks.ready;
            await decoder.completed;
            const count = decoder.tracks.selectedTrack.frameCount;
            if (count > 600) throw new Error("This animation has too many frames to quote (600 maximum).");
            const boundaries = [];
            let duration = 0, width = 0, height = 0;
            for (let i = 0; i < count; i++) {
                const { image } = await decoder.decode({ frameIndex: i });
                width = image.displayWidth; height = image.displayHeight;
                boundaries.push(duration);
                duration += Math.max(20, (image.duration || 100000) / 1000);
                image.close();
            }
            if (count > 1 && duration > 30000) throw new Error("Animated quotes support clips up to 30 seconds.");
            return {
                width, height, duration: count > 1 ? duration : 0, boundaries,
                async frameAt(time) {
                    const local = time % duration;
                    let index = 0;
                    while (index + 1 < count && boundaries[index + 1] <= local) index++;
                    const { image } = await decoder.decode({ frameIndex: index });
                    return { image, close() { image.close(); } };
                },
                close() { decoder.close(); },
            };
        } catch (error) { decoder.close(); throw error; }
    }
    if (type === 'image/gif' || type === 'image/webp') throw new Error("Update Android System WebView to quote animated images.");
    const url = URL.createObjectURL(blob);
    try {
        const image = new Image();
        await mediaEvent(image, 'load', () => { image.src = url; });
        return { width: image.naturalWidth, height: image.naturalHeight, duration: 0, boundaries: [0], async frameAt() { return { image, close() {} }; }, close() {} };
    } finally { URL.revokeObjectURL(url); }
}
async function exportMedia(canvas, media, rectangles, renderId) {
    const ctx = canvas.getContext('2d');
    const duration = Math.max(0, ...media.map(item => item.duration));
    const times = new Set([0]);
    for (const item of media) {
        if (!item.duration) continue;
        for (let loop = 0; loop < duration; loop += item.duration) {
            for (const boundary of item.boundaries) if (loop + boundary < duration) times.add(loop + boundary);
        }
    }
    const timeline = Array.from(times).sort((a, b) => a - b);
    if (timeline.length > 600) throw new Error("Combined animation exceeds 600 frames. Quote fewer animated attachments.");
    const gif = duration ? GIF.GIFEncoder() : null;
    let palette;
    let indexed;
    const lastFrames = media.map(() => -1);
    const frameCaches = media.map(() => new Map());
    let cachedBytes = 0;
    if (gif) {
        await Promise.all(media.map(async (item, m) => {
            const frame = await item.frameAt(0);
            const rect = rectangles[m];
            try {
                ctx.fillStyle = '#000';
                ctx.fillRect(rect.x, rect.y, rect.width, rect.height);
                ctx.drawImage(frame.image, rect.x, rect.y, rect.width, rect.height);
            } finally { frame.close(); }
        }));
        post({ type: 'preview', renderId, dataUrl: canvas.toDataURL('image/png'), width: canvas.width, height: canvas.height });
        // One palette for the entire GIF keeps all static pixels identical between frames.
        const sample = document.createElement('canvas');
        sample.width = sample.height = 128;
        const sampleContext = sample.getContext('2d');
        sampleContext.drawImage(canvas, 0, 0, 128, 128);
        const chunks = [sampleContext.getImageData(0, 0, 128, 128).data];
        sample.width = sample.height = 32;
        const sampleCount = Math.min(12, timeline.length);
        for (let index = 0; index < sampleCount; index++) {
            const time = timeline[Math.round(index * (timeline.length - 1) / Math.max(1, sampleCount - 1))];
            await Promise.all(media.map(async item => {
                if (!item.duration && index) return;
                const frame = await item.frameAt(time);
                try {
                    sampleContext.fillStyle = '#000';
                    sampleContext.fillRect(0, 0, 32, 32);
                    sampleContext.drawImage(frame.image, 0, 0, 32, 32);
                    chunks.push(sampleContext.getImageData(0, 0, 32, 32).data);
                } finally { frame.close(); }
            }));
            post({ type: 'progress', renderId, message: 'Preparing animation ' + Math.round((index + 1) / sampleCount * 100) + '%' });
            await new Promise(resolve => setTimeout(resolve, 0));
        }
        const samples = new Uint8Array(chunks.reduce((size, chunk) => size + chunk.length, 0));
        let offset = 0;
        for (const chunk of chunks) { samples.set(chunk, offset); offset += chunk.length; }
        palette = GIF.quantize(samples, 256);
    }
    for (let index = 0; index < timeline.length; index++) {
        const changed = [];
        await Promise.all(media.map(async (item, m) => {
            const local = item.duration ? timeline[index] % item.duration : 0;
            let frameIndex = 0;
            while (frameIndex + 1 < item.boundaries.length && item.boundaries[frameIndex + 1] <= local) frameIndex++;
            if (gif && index === 0) { lastFrames[m] = frameIndex; changed.push(m); return; }
            if (lastFrames[m] === frameIndex) return;
            lastFrames[m] = frameIndex;
            changed.push(m);
            if (frameCaches[m].has(frameIndex)) return;
            const rect = rectangles[m];
            const frame = await item.frameAt(item.boundaries[frameIndex]);
            try {
                ctx.fillStyle = '#000';
                ctx.fillRect(rect.x, rect.y, rect.width, rect.height);
                ctx.drawImage(frame.image, rect.x, rect.y, rect.width, rect.height);
            } finally { frame.close(); }
        }));
        if (gif) {
            const firstFrame = !indexed;
            if (firstFrame) indexed = GIF.applyPalette(ctx.getImageData(0, 0, canvas.width, canvas.height).data, palette);
            for (const m of changed) {
                if (!media[m].duration) continue;
                const rect = rectangles[m];
                let pixels = frameCaches[m].get(lastFrames[m]);
                if (!pixels) {
                    if (firstFrame) {
                        pixels = new Uint8Array(rect.width * rect.height);
                        for (let row = 0; row < rect.height; row++) {
                            const start = (rect.y + row) * canvas.width + rect.x;
                            pixels.set(indexed.subarray(start, start + rect.width), row * rect.width);
                        }
                    } else {
                        pixels = GIF.applyPalette(ctx.getImageData(rect.x, rect.y, rect.width, rect.height).data, palette);
                    }
                    // Bound memory while reusing frames when a shorter animation loops.
                    if (cachedBytes + pixels.byteLength <= 32 * 1024 * 1024) {
                        frameCaches[m].set(lastFrames[m], pixels);
                        cachedBytes += pixels.byteLength;
                    }
                }
                for (let row = 0; row < rect.height; row++) {
                    indexed.set(pixels.subarray(row * rect.width, (row + 1) * rect.width), (rect.y + row) * canvas.width + rect.x);
                }
            }
            let framePixels = indexed, x = 0, y = 0, width = canvas.width, height = canvas.height;
            if (index) {
                const regions = changed.map(m => rectangles[m]);
                x = regions.length ? Math.min(...regions.map(rect => rect.x)) : 0;
                y = regions.length ? Math.min(...regions.map(rect => rect.y)) : 0;
                width = regions.length ? Math.max(...regions.map(rect => rect.x + rect.width)) - x : 1;
                height = regions.length ? Math.max(...regions.map(rect => rect.y + rect.height)) - y : 1;
                framePixels = new Uint8Array(width * height);
                for (let row = 0; row < height; row++) {
                    const start = (y + row) * canvas.width + x;
                    framePixels.set(indexed.subarray(start, start + width), row * width);
                }
            }
            gif.writeFrame(framePixels, width, height, { x, y, dispose: 1, palette: index ? undefined : palette, delay: (timeline[index + 1] ?? duration) - timeline[index], repeat: 0 });
            if (gif.bytesView().length > 25 * 1024 * 1024) throw new Error("The animated quote exceeds 25 MB. Try fewer attachments or less text.");
            post({ type: 'progress', renderId, message: 'Rendering animation ' + Math.round((index + 1) / timeline.length * 100) + '%' });
            await new Promise(resolve => setTimeout(resolve, 0));
        }
    }
    if (!gif) return canvas.toDataURL('image/png');
    gif.finish();
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(new Error('Could not export animated quote.'));
        reader.readAsDataURL(new Blob([gif.bytes()], { type: 'image/gif' }));
    });
}
`;function C(e){var t=JSON.stringify(e).replace(/<\/script/gi,`<\\/script`);return`<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<style>
${e.reply?`@font-face { font-family: 'gg sans'; font-weight: 400; src: url('file:///android_asset/fonts/ggsans-Normal.ttf'); } @font-face { font-family: 'gg sans'; font-weight: 600; src: url('file:///android_asset/fonts/ggsans-Semibold.ttf'); }`:`@import url('https://fonts.googleapis.com/css2?family=M+PLUS+Rounded+1c:wght@300&display=swap');`}
html, body {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
    background: #000;
    overflow: hidden;
}
canvas {
    width: 100%;
    height: 100%;
    display: block;
}
</style>
</head>
<body>
<canvas id="q" width="1200" height="600"></canvas>
<script>
const payload = ${t};
${e.media?.length||e.reply?.media?.length?`${x}\n${S}`:``}

function post(data) {
    try {
        window.ReactNativeWebView.postMessage(JSON.stringify(data));
    } catch {}
}

async function waitForFonts(font) {
    try {
        await Promise.race([
            Promise.all([
                document.fonts.load("300 42px '" + font + "'"),
                document.fonts.load("italic 300 26px '" + font + "'"),
                document.fonts.ready,
            ]),
            new Promise(resolve => setTimeout(resolve, 4000)),
        ]);
    } catch {}
}

function calculateTextLines(ctx, text, fontSize, font, maxWidth, firstWidth = maxWidth) {
    ctx.font = "300 " + fontSize + "px '" + font + "', sans-serif";
    const lines = [];
    const segmenter = typeof Intl.Segmenter === "function" ? new Intl.Segmenter(undefined, { granularity: "grapheme" }) : null;
    for (const paragraph of String(text || "").split("\\n")) {
        let line = "";
        for (const word of paragraph.split(/\\s+/).filter(Boolean)) {
            const candidate = line ? line + " " + word : word;
            if (ctx.measureText(candidate).width <= (lines.length ? maxWidth : firstWidth)) { line = candidate; continue; }
            if (line) { lines.push(line); line = ""; }
            const units = segmenter ? Array.from(segmenter.segment(word), part => part.segment) : Array.from(word);
            for (const unit of units) {
                if (line && ctx.measureText(line + unit).width > (lines.length ? maxWidth : firstWidth)) { lines.push(line); line = ""; }
                line += unit;
            }
        }
        lines.push(line);
    }

    return lines;
}

function calculateFont(ctx, quote, font, cfg, fs, sp) {
    let fontSize = fs.initial;
    while (fontSize >= fs.minimum) {
        const lines = calculateTextLines(ctx, quote, fontSize, font, cfg.quoteAreaWidth);
        const lineHeight = fontSize * fs.lineHeightMultiplier;
        const authorFontSize = Math.max(fs.authorMinimum, fontSize * fs.authorMultiplier);
        const usernameFontSize = Math.max(fs.usernameMinimum, fontSize * fs.usernameMultiplier);
        const totalHeight = (lines.length * lineHeight) + sp.authorTop + authorFontSize + sp.username + usernameFontSize;
        if (totalHeight <= cfg.maxContentHeight) {
            return { lines, fontSize, lineHeight, authorFontSize, usernameFontSize, totalHeight };
        }
        fontSize -= fs.decrement;
    }

    const lines = calculateTextLines(ctx, quote, fs.minimum, font, cfg.quoteAreaWidth);
    const lineHeight = fs.minimum * fs.lineHeightMultiplier;
    return {
        lines,
        fontSize: fs.minimum,
        lineHeight,
        authorFontSize: fs.authorMinimum,
        usernameFontSize: fs.usernameMinimum,
        totalHeight: (lines.length * lineHeight) + sp.authorTop + fs.authorMinimum + sp.username + fs.usernameMinimum,
    };
}

async function loadAvatar(url) {
    // Time-cap the fetch so a stalled connection surfaces as an error
    // instead of leaving the preview stuck on "Generating..." forever.
    const response = await Promise.race([
        fetch(url),
        new Promise((_, reject) => setTimeout(() => reject(new Error("Avatar request timed out.")), 10000)),
    ]);
    if (!response.ok) throw new Error("Failed to fetch avatar image.");
    const blob = await response.blob();
    const blobUrl = URL.createObjectURL(blob);

    try {
        return await new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = () => resolve(img);
            img.onerror = () => reject(new Error("Failed to load avatar image."));
            img.src = blobUrl;
        });
    } finally {
        URL.revokeObjectURL(blobUrl);
    }
}

async function render() {
    const media = [];
    try {
    const replyMediaCount = payload.reply?.media?.length || 0;
    const loaded = await Promise.allSettled([...(payload.reply?.media || []), ...(payload.media || [])].map(item => loadMedia(item)));
    for (const result of loaded) if (result.status === 'fulfilled') media.push(result.value);
    const failure = loaded.find(result => result.status === 'rejected');
    if (failure) throw failure.reason;
    const cfg = payload.reply ? { ...payload.canvas, width: 1200 } : payload.canvas;
    const fs = payload.fonts;
    const sp = payload.spacing;
    const quoteFont = payload.reply ? "gg sans" : payload.quoteFont || "M PLUS Rounded 1c";

    if (payload.reply) await Promise.all([document.fonts.load("400 32px 'gg sans'"), document.fonts.load("600 30px 'gg sans'")]);
    else await waitForFonts(quoteFont);

    const canvas = document.getElementById("q");
    canvas.width = cfg.width;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Canvas context unavailable.");
    const quote = String(payload.quote || " ");
    const reply = payload.reply;
    const areaX = reply ? 24 : cfg.quoteAreaX;
    let areaWidth = reply ? cfg.width - 48 : cfg.quoteAreaWidth;
    let blockWidth = areaWidth;
    if (reply) {
        ctx.font = "400 32px 'gg sans', sans-serif";
        const bodyWidth = Math.max(...quote.split('\\n').map(line => ctx.measureText(line).width)) + 108;
        ctx.font = "600 24px 'gg sans', sans-serif";
        const referenceNameWidth = ctx.measureText(reply.displayName).width;
        ctx.font = "400 24px 'gg sans', sans-serif";
        const referenceHeaderWidth = referenceNameWidth + 158 + (reply.timestamp ? ctx.measureText(reply.timestamp).width + 18 : 0);
        const referenceWidth = referenceHeaderWidth + Math.max(...reply.text.split('\\n').map(line => ctx.measureText(line).width));
        ctx.font = "600 30px 'gg sans', sans-serif";
        const headerWidth = ctx.measureText(payload.displayName).width + 108 + (payload.isBot ? 190 : 120);
        blockWidth = Math.max(headerWidth, referenceHeaderWidth + 120, Math.min(areaWidth, Math.max(bodyWidth, referenceWidth)));
        areaWidth = blockWidth;
    }
    if (reply) {
        cfg.width = Math.ceil(blockWidth + areaX * 2);
        canvas.width = cfg.width;
    }
    const blockX = reply ? areaX : areaX + (areaWidth - blockWidth) / 2;
    const contentWidth = blockWidth - (reply ? 108 : 0);
    const calculation = calculateFont(ctx, quote, quoteFont, cfg, fs, sp);
    const messageLines = reply ? (quote.trim() ? calculateTextLines(ctx, quote, 32, 'gg sans', contentWidth) : []) : calculation.lines;
    ctx.font = "600 24px 'gg sans', sans-serif";
    const replyNameWidth = reply ? ctx.measureText(reply.displayName).width : 0;
    ctx.font = "400 24px 'gg sans', sans-serif";
    const replyTimestampWidth = reply?.timestamp ? ctx.measureText(reply.timestamp).width + 18 : 0;
    const replyFirstWidth = blockWidth - 158 - replyNameWidth - replyTimestampWidth;
    const replyLines = reply ? calculateTextLines(ctx, reply.text, 24, 'gg sans', contentWidth, replyFirstWidth) : [];
    let replyHeight = reply ? replyLines.length * 30 + 22 : 0;
    const rectangles = media.map((item, index) => {
        const ratio = Math.min(contentWidth / item.width, (index < replyMediaCount ? 240 : 360) / item.height);
        return { width: Math.round(item.width * ratio), height: Math.round(item.height * ratio), x: 0, y: 0 };
    });
    const replyRectangles = rectangles.slice(0, replyMediaCount);
    replyHeight += replyRectangles.reduce((sum, rect) => sum + rect.height + 24, 0);
    const messageRectangles = rectangles.slice(replyMediaCount);
    const mediaHeight = messageRectangles.reduce((sum, rect) => sum + rect.height + 24, 0);
    const totalHeight = reply ? replyHeight + 42 + messageLines.length * 42 + mediaHeight : calculation.totalHeight + mediaHeight;
    const height = reply ? Math.ceil(totalHeight + 80) : Math.max(cfg.height, Math.ceil(totalHeight + 120));
    if (height > 16384) throw new Error("This quote is too tall for one image. Choose a shorter message.");
    canvas.height = height;

    ctx.fillStyle = reply ? "#1c1d22" : "#000";
    ctx.fillRect(0, 0, cfg.width, height);

    if (!reply) {
        const avatar = await loadAvatar(payload.avatarUrl);
        ctx.drawImage(avatar, 0, (height - cfg.height) / 2, cfg.height, cfg.height);
        if (payload.grayscale) {
            ctx.globalCompositeOperation = 'saturation';
            ctx.fillStyle = '#fff';
            ctx.fillRect(0, 0, cfg.width, height);
            ctx.globalCompositeOperation = 'source-over';
        }
        const gradient = ctx.createLinearGradient(cfg.height - sp.gradientWidth, 0, cfg.height, 0);
        gradient.addColorStop(0, 'rgba(0, 0, 0, 0)');
        gradient.addColorStop(1, 'rgba(0, 0, 0, 1)');
        ctx.fillStyle = gradient;
        ctx.fillRect(cfg.height - sp.gradientWidth, 0, sp.gradientWidth, height);
    }

    ctx.save();
    ctx.beginPath();
    ctx.rect(areaX, 40, areaWidth, height - 80);
    ctx.clip();
    ctx.textAlign = "center";
    ctx.textBaseline = "top";
    const centerX = cfg.quoteAreaX + cfg.quoteAreaWidth / 2;
    ctx.fillStyle = "#fff";
    ctx.font = "300 " + calculation.fontSize + "px '" + quoteFont + "', sans-serif";
    let quoteY = (height - totalHeight) / 2;
    if (reply) {
        const x = blockX;
        const avatar = await loadAvatar(payload.avatarUrl);
        const replyAvatar = await loadAvatar(reply.avatarUrl);
        ctx.strokeStyle = '#4e5058'; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.moveTo(x + 42, quoteY + replyHeight - 8);
        ctx.lineTo(x + 42, quoteY + 24);
        ctx.quadraticCurveTo(x + 42, quoteY + 14, x + 52, quoteY + 14);
        ctx.lineTo(x + 92, quoteY + 14); ctx.stroke();
        ctx.save(); ctx.beginPath(); ctx.arc(x + 122, quoteY + 14, 14, 0, Math.PI * 2); ctx.clip();
        ctx.drawImage(replyAvatar, x + 108, quoteY, 28, 28); ctx.restore();
        ctx.textAlign = 'left';
        ctx.fillStyle = reply.color;
        ctx.font = "600 24px 'gg sans', sans-serif";
        ctx.fillText(reply.displayName, x + 144, quoteY, replyNameWidth);
        ctx.fillStyle = '#949ba4';
        ctx.font = "400 24px 'gg sans', sans-serif";
        if (reply.timestamp) ctx.fillText(reply.timestamp, x + 158 + replyNameWidth, quoteY, replyTimestampWidth - 18);
        ctx.fillStyle = '#b5bac1';
        replyLines.forEach((line, index) => ctx.fillText(line, index ? x + 108 : x + 158 + replyNameWidth + replyTimestampWidth, quoteY + index * 30, index ? contentWidth : replyFirstWidth));
        let replyMediaY = quoteY + replyLines.length * 30 + 12;
        for (const rect of replyRectangles) {
            rect.x = Math.round(x + 108);
            rect.y = Math.round(replyMediaY);
            replyMediaY += rect.height + 24;
        }
        quoteY += replyHeight;
        ctx.save(); ctx.beginPath(); ctx.arc(x + 42, quoteY + 42, 42, 0, Math.PI * 2); ctx.clip();
        ctx.drawImage(avatar, x, quoteY, 84, 84); ctx.restore();
        ctx.fillStyle = payload.authorColor || '#f2f3f5';
        ctx.font = "600 30px 'gg sans', sans-serif";
        const nameWidth = ctx.measureText(payload.displayName).width;
        ctx.fillText(payload.displayName, x + 108, quoteY, nameWidth);
        let headerX = x + 108 + nameWidth + 18;
        if (payload.isBot) {
            ctx.fillStyle = '#5865f2';
            ctx.fillRect(headerX, quoteY + 3, 60, 32);
            ctx.fillStyle = '#fff'; ctx.font = "600 22px 'gg sans', sans-serif";
            ctx.fillText('APP', headerX + 6, quoteY + 7, 48);
            headerX += 74;
        }
        ctx.fillStyle = '#949ba4'; ctx.font = "400 24px 'gg sans', sans-serif";
        ctx.fillText(payload.timestamp || '', headerX, quoteY + 9, blockX + blockWidth - headerX);
        quoteY += 42;
        ctx.fillStyle = '#dbdee1';
        ctx.font = "400 32px 'gg sans', sans-serif";
    }
    for (const line of messageLines) {
        ctx.fillText(line, reply ? blockX + 108 : centerX, quoteY, contentWidth);
        quoteY += reply ? 42 : calculation.lineHeight;
    }
    for (const rect of messageRectangles) {
        rect.x = Math.round(reply ? blockX + 108 : centerX - rect.width / 2);
        rect.y = Math.round(quoteY + 24);
        quoteY += rect.height + 24;
    }
    if (!reply) {
    ctx.font = "italic 300 " + calculation.authorFontSize + "px '" + quoteFont + "', sans-serif";
    const authorY = quoteY + sp.authorTop;
    ctx.fillText("- " + String(payload.displayName || "Unknown"), centerX, authorY, cfg.quoteAreaWidth);
    ctx.font = "300 " + calculation.usernameFontSize + "px '" + quoteFont + "', sans-serif";
    ctx.fillStyle = "#888";
    const usernameY = authorY + calculation.authorFontSize + sp.username;
    ctx.fillText(String(payload.username || "@unknown"), centerX, usernameY, cfg.quoteAreaWidth);
    }
    ctx.restore();

    if (payload.showWatermark && payload.watermark) {
        const watermarkText = String(payload.watermark).slice(0, 32);
        ctx.fillStyle = "#888";
        ctx.font = "300 " + fs.watermark + "px '" + quoteFont + "', sans-serif";
        ctx.textAlign = reply ? "left" : "right";
        ctx.textBaseline = "alphabetic";
        const watermarkX = reply ? blockX + 108 : cfg.width - sp.watermarkPadding;
        const watermarkY = reply ? quoteY + 24 : height - sp.watermarkPadding;
        ctx.fillText(watermarkText, watermarkX, watermarkY, reply ? contentWidth : cfg.quoteAreaWidth);
    }

    const dataUrl = media.length ? await exportMedia(canvas, media, rectangles, payload.renderId) : canvas.toDataURL("image/png");
    post({ type: "result", dataUrl, width: cfg.width, height, renderId: payload.renderId });
    } finally { for (const item of media) item.close(); }
}

render().catch(error => {
    post({
        type: "error",
        renderId: payload.renderId,
        message: String(error && error.message ? error.message : error),
    });
});
<\/script>
</body>
</html>`}async function w(e,t,n,r){var i=/^data:(image\/(?:png|gif));base64,([A-Za-z0-9+/]+={0,2})$/.exec(t.dataUrl);if(!i||i[2].length%4!=0)throw Error(`Invalid rendered quote image.`);var[,a,o]=i,[s]=valenced.modules.finders.lookupModule(valenced.modules.finders.filters.withProps(`sendMessage`,`receiveMessage`)),[c]=valenced.modules.finders.lookupModule(valenced.modules.finders.filters.withProps(`CloudUpload`)),[l]=valenced.modules.finders.lookupModule(valenced.modules.finders.filters.withProps(`UploadPlatform`));if(!s||!c||!l)throw Error(`Native attachment uploads are unavailable.`);var u=a===`image/gif`?`gif`:`png`;n=n.replace(/\.(png|gif)$/i,`.${u}`);var d=`dev.benjii.quoter/${Date.now()}-${Math.random().toString(16).slice(2)}.${u}`,f=String(await valenced.discord.native.FileModule.writeFile(`cache`,d,o,`base64`)),p=f.startsWith(`file://`)?f:`file://${f}`,m=!1,h=!1;try{var g=new c.CloudUpload({platform:l.UploadPlatform.REACT_NATIVE,uri:p,filename:n,mimeType:a},e,0,!1),_;m=!0;var v=await s.sendMessage(e,{content:``,invalidEmojis:[],validNonShortcutEmojis:[],tts:!1},!1,{attachmentsToUpload:[g],onAttachmentUploadError(e,t,n){r.warn(`Native quote upload failed`,t,n),_=/* @__PURE__ */ Error(`Could not upload the quote attachment.`)}});if(_)throw _;if(!v?.ok)throw Error(`Discord could not send the quote. Check the failed message before retrying.`);h=!0}finally{if(h||!m)try{await valenced.discord.native.FileModule.removeFile(`cache`,d)}catch(e){r.warn(`Could not remove cached quote`,e)}}}var T=`Made with Valenced`,E={grayscale:!1,quotationMarks:!1,allowMedia:!1,allowReplies:!1,showWatermark:!1,watermark:T},D=E,O,k=!1,A=/* @__PURE__ */ new Set;function j(e){O=e}async function M(){var e=O.cache??await O.get();if(!e)throw Error(`Could not load Quoter settings.`);D={...E,...e},N()}function N(){for(var e of A)e()}function P(e){k=e,N()}function F(e){return A.add(e),function(){A.delete(e)}}function I(){return valenced.react.React.useSyncExternalStore(F,function(){return k})}function L(e){D={...D,...e},O.set(D,!0),N()}function R(){return{...valenced.react.React.useSyncExternalStore(F,function(){return D}),updateSettings:L}}R.subscribe=F;var z=`dev.benjii.quoter.preview`;function B(){valenced.discord.actions.AlertActionCreators.dismissAlert(z)}function V(e,t){valenced.discord.actions.AlertActionCreators.openAlert(z,/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsx(H,{message:e,api:t}))}function H({message:e,api:t}){var{height:n}=valenced.react.ReactNative.useWindowDimensions(),r=R(),i=I(),[a]=valenced.react.React.useState(function(){var e=valenced.modules.finders.lookupModule(valenced.modules.finders.filters.withProps(`WebView`),{initialize:!1})[0]?.WebView;if(e)return e;var[,t]=valenced.modules.finders.lookupModule(valenced.modules.finders.filters.withName(`codegenNativeCommands`));if(t!==void 0)return valenced.modules.finders.lookupModule(valenced.modules.finders.filters.withDependencies([valenced.react.ReactModuleId,valenced.react.ReactNativeModuleId,valenced.react.ReactJSXRuntimeModuleId,t,null,null,null,null,null]).and(valenced.modules.finders.filters.withProps(`render`,`isFileUploadSupported`)))[0]}),[o,s]=valenced.react.React.useState(),[c,l]=valenced.react.React.useState(``),u=r.allowReplies&&!!f(e),[d,p]=valenced.react.React.useState(r.watermark);valenced.react.React.useEffect(function(){if(d!==r.watermark){var e=setTimeout(function(){return r.updateSettings({watermark:d})},500);return function(){return clearTimeout(e)}}},[d,r.watermark]);var{id:m,html:h}=valenced.react.React.useMemo(function(){var t=`${Date.now()}-${Math.random()}`;return{id:t,html:C({...b(e,r,u),renderId:t})}},[e,r.grayscale,r.showWatermark,r.watermark,r.quotationMarks,r.allowMedia,r.allowReplies,u]);valenced.react.React.useEffect(function(){l(``)},[m]);var g=o?.id===m?o.image:void 0,y=o?.id===m&&o.ready,x=async function(){if(g&&y&&i&&d===r.watermark){var n=_(e);if(!n)l(`Unable to resolve channel.`);else{B();try{await w(n,g,v(e),t.logger),valenced.discord.actions.ToastActionCreators.open(`QUOTER_SENT`,{text:`Quote sent.`})}catch(e){t.plugin.reportError(e),valenced.discord.actions.ToastActionCreators.open(`QUOTER_FAILED`,{text:`Failed to send quote: ${e instanceof Error?e.message:String(e)}`,variant:`critical`})}}}};return/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsx(valenced.discord.design.Design.AlertModal,{title:`Create Quote`,content:`Preview generated from selected message`,extraContent:/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsxs(valenced.react.ReactNative.ScrollView,{style:{maxHeight:Math.max(160,n-280)},contentContainerStyle:{paddingTop:10,paddingBottom:4},children:[/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsxs(valenced.react.ReactNative.View,{style:{width:`100%`,aspectRatio:g?g.width/g.height:2,maxHeight:260,alignSelf:`center`,borderRadius:14,overflow:`hidden`,backgroundColor:`#0f0f0f`,justifyContent:`center`,alignItems:`center`},children:[g?/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsx(valenced.react.ReactNative.Image,{source:{uri:g.dataUrl},resizeMode:`contain`,style:{width:`100%`,height:`100%`}}):a?null:/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsx(valenced.discord.design.Design.Text,{variant:`text-xs/medium`,children:`WebView unavailable. Cannot render quote.`}),a&&i&&!y&&!c&&/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsx(valenced.react.ReactNative.View,{pointerEvents:`none`,style:{position:`absolute`,left:0,top:0,right:0,bottom:0,alignItems:`center`,justifyContent:`center`},children:/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsx(valenced.react.ReactNative.View,{style:{backgroundColor:`#0009`,borderRadius:24,padding:8},children:/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsx(valenced.react.ReactNative.ActivityIndicator,{size:`small`,color:`#fff`,accessibilityLabel:`Preparing quote`})})})]}),a&&i?/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsx(a,{source:{html:h,baseUrl:u?`file:///android_asset/`:`https://localhost`},javaScriptEnabled:!0,onMessage:function(e){try{var t=JSON.parse(e.nativeEvent.data);if(t.renderId!==m)return;(t.type===`result`||t.type===`preview`)&&typeof t.dataUrl==`string`&&/^data:image\/(png|gif);base64,/.test(t.dataUrl)&&t.width>0&&t.height>0?s({id:m,ready:t.type===`result`,image:{dataUrl:t.dataUrl,width:t.width,height:t.height}}):t.type===`error`&&l(String(t.message))}catch{l(`Invalid renderer response.`)}},onError:function(){return l(`Could not load the quote renderer.`)},style:{width:1,height:1,opacity:0,position:`absolute`,left:-9999,top:-9999}},m):null,!!c&&/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsx(valenced.discord.design.Design.Text,{color:`text-feedback-critical`,children:c}),/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsx(valenced.discord.design.Design.TableSwitchRow,{label:`Quotation marks`,value:r.quotationMarks,onValueChange:function(e){return r.updateSettings({quotationMarks:e})}}),/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsx(valenced.discord.design.Design.TableSwitchRow,{label:`Grayscale`,value:r.grayscale,onValueChange:function(e){return r.updateSettings({grayscale:e})}}),/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsx(valenced.discord.design.Design.TableSwitchRow,{label:`Show Watermark`,value:r.showWatermark,onValueChange:function(e){return r.updateSettings({showWatermark:e})}}),r.showWatermark&&/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsx(valenced.discord.design.Design.TextInput,{label:`Watermark text`,value:d,maxLength:32,onChange:p})]}),actions:/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsxs(valenced.react.ReactJSXRuntime.Fragment,{children:[/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsx(valenced.discord.design.Design.AlertActionButton,{text:`Send`,variant:`primary`,disabled:!y||!i||d!==r.watermark,onPress:function(){x()}}),/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsx(valenced.discord.design.Design.AlertActionButton,{text:`Cancel`,variant:`secondary`,onPress:B})]})})}function U({api:{jsonStorage:e,plugin:t}}){j(e),e.use(),valenced.react.React.useEffect(function(){M().catch(function(e){return t.reportError(e)})},[t]);var n=R();return/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsx(valenced.react.ReactNative.ScrollView,{style:{flex:1},contentContainerStyle:{paddingBottom:38},children:/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsxs(valenced.discord.design.Design.Stack,{style:{paddingVertical:24,paddingHorizontal:12},spacing:24,children:[/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsxs(valenced.discord.design.Design.TableRowGroup,{title:`Quote content`,children:[/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsx(valenced.discord.design.Design.TableSwitchRow,{label:`Quotation marks`,subLabel:`Add " on both sides of the quote text.`,value:n.quotationMarks,onValueChange:function(e){return n.updateSettings({quotationMarks:e})}}),/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsx(valenced.discord.design.Design.TableSwitchRow,{label:`Allow media`,subLabel:`Include images and GIFs. Animated media exports as a GIF.`,value:n.allowMedia,onValueChange:function(e){return n.updateSettings({allowMedia:e})}}),/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsx(valenced.discord.design.Design.TableSwitchRow,{label:`Allow replies`,subLabel:`Include the referenced message when quoting replies.`,value:n.allowReplies,onValueChange:function(e){return n.updateSettings({allowReplies:e})}})]}),/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsxs(valenced.discord.design.Design.TableRowGroup,{title:`Rendering`,children:[/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsx(valenced.discord.design.Design.TableSwitchRow,{label:`Grayscale`,subLabel:`Render the avatar in black and white`,icon:/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsx(valenced.discord.design.Design.TableRow.Icon,{source:valenced.assets.getAssetIdByName(`ImageIcon`)}),value:!!n.grayscale,onValueChange:function(e){return n.updateSettings({grayscale:e})}}),/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsx(valenced.discord.design.Design.TableSwitchRow,{label:`Show Watermark`,subLabel:`Draw watermark text in the bottom-right corner`,icon:/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsx(valenced.discord.design.Design.TableRow.Icon,{source:valenced.assets.getAssetIdByName(`PencilIcon`)}),value:!!n.showWatermark,onValueChange:function(e){return n.updateSettings({showWatermark:e})}})]}),n.showWatermark?/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsx(valenced.discord.design.Design.TextInput,{label:`Watermark Text`,description:`Only used when watermark is enabled. Max 32 characters.`,placeholder:T,size:`md`,maxLength:32,value:String(n.watermark??``),onChange:function(e){return n.updateSettings({watermark:e})}}):null]})})}return e.default=plugin({jsonStorage:{default:E},SettingsComponent:U,async start(e){var{cleanup:t,jsonStorage:r,plugin:i}=e,a=!1;t(function(){a=!0,P(!1),B()}),i.startedLate&&i.requireReload(),j(r),await M(),!a&&(P(!0),t(valenced.modules.finders.getModules(valenced.modules.finders.filters.withName(`LongPressMessageActionSheet`),function(r){var i=r;t(valenced.patcher.instead(i,`default`,function(t,r){var i=Reflect.apply(r,this,t),a=t[0].message;if(!a||!a.content&&!(D.allowMedia&&n(a).length))return i;var o=!1,s=function(t){if(!/*#__PURE__*/ valenced.react.React.isValidElement(t))return t;var n=valenced.react.React.Children.toArray(t.props.children);if(!o&&t.props.hasIcons&&n.some(function(e){return/*#__PURE__*/ valenced.react.React.isValidElement(e)&&typeof e.props.label==`string`})){var r=n.find(function(e){return/*#__PURE__*/ valenced.react.React.isValidElement(e)&&typeof e.props.label==`string`});if(/*#__PURE__*/ valenced.react.React.isValidElement(r)){o=!0;var i=r.type,c=/*#__PURE__*/ valenced.react.React.isValidElement(r.props.icon)?/*#__PURE__*/ valenced.react.React.cloneElement(r.props.icon,{IconComponent:valenced.utils.discord.lookupGeneratedIconComponent(`QuoteIcon`)}):void 0;return/*#__PURE__*/ valenced.react.React.cloneElement(t,{},...n,/*#__PURE__*/ valenced.react.ReactJSXRuntime.jsx(i,{label:`Quote`,icon:c,onPress:function(){valenced.discord.actions.ActionSheetActionCreators.hideAllActionSheets(),V(a,e)}},`quoter`))}}return/*#__PURE__*/ valenced.react.React.cloneElement(t,{},valenced.react.React.Children.map(t.props.children,s))};return s(i)}))},{returnNamespace:!0})))}}),e})({});