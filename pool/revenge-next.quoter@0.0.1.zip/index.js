(function(e){Object.defineProperty(e,Symbol.toStringTag,{value:`Module`});var t=function(...e){return valenced.react.ReactJSXRuntime.jsx(...e)},n=function(...e){return valenced.react.ReactJSXRuntime.jsxs(...e)};function r(e){if(e)try{var t=new URL(e);return t.protocol===`https:`||t.protocol===`http:`?e:void 0}catch{return}}function i(e){var t=[],n=function(e,n){var i=r(e);i&&!t.some(function(e){return e.url===i})&&t.push({url:i,kind:n})};for(var i of e.attachments??[]){var a=i.content_type??i.contentType??``,o=i.url??i.proxy_url??i.proxyURL;(a.startsWith(`image/`)||/\.(png|jpe?g|gif|webp|avif)(?:[?#]|$)/i.test(o??``))&&n(o,`image`)}for(var s of e.embeds??[])s.type===`gifv`&&s.video?n(s.video.url??s.video.proxy_url??s.video.proxyURL,`video`):s.image?n(s.image.proxy_url??s.image.proxyURL??s.image.url,`image`):s.type===`image`&&n(s.thumbnail?.proxy_url??s.thumbnail?.proxyURL??s.thumbnail?.url??s.url,`image`);return t}function a(e){if(e.referenced_message)return e.referenced_message;var t=e.referencedMessage;return t&&(`message`in t?t.message:t)}function o(e,t){return t&&e.trim()?`"${e}"`:e}function s(e,t){var n=e.content??``;if(!t.length)return n;var r=function(e){try{var t=new URL(e);if([`cdn.discordapp.com`,`media.discordapp.net`].includes(t.hostname)&&t.pathname.startsWith(`/attachments/`))return t.pathname}catch{}return e},a=t.map(function(e){return e.url});for(var o of e.attachments??[])if(i({attachments:[o]}).length)for(var s of[o.url,o.proxy_url,o.proxyURL])s&&a.push(s);for(var c of e.embeds??[])c.url&&i({embeds:[c]}).length&&a.push(c.url);return a.some(function(e){return r(e)===r(n.trim())})?``:n}var c={width:1200,height:600,quoteAreaWidth:520,quoteAreaX:640,maxContentHeight:480},l={initial:42,minimum:18,decrement:2,lineHeightMultiplier:1.25,authorMultiplier:.6,usernameMultiplier:.45,authorMinimum:22,usernameMinimum:18,watermark:18},u={authorTop:60,username:10,gradientWidth:400,watermarkPadding:20};function d(e){return e?String(e).replace(/\r\n?/g,`
`).split(`
`).map(function(e){return e.replace(/[^\S\n]+/g,` `).trim()}).join(`
`).trim():``}function f(e){if(!e||typeof e!=`string`)return``;try{var t=new URL(e);return t.searchParams.set(`size`,`512`),(t.hostname===`cdn.discordapp.com`||t.hostname===`media.discordapp.net`)&&(t.pathname=t.pathname.replace(/\.(webp|gif|jpg|jpeg)$/i,`.png`),t.searchParams.set(`format`,`png`)),t.toString()}catch{return e}}function p(e){var t=String(e??``).replace(/<a?:(\w+):(\d+)>/g,``),n=t.match(/<@!?\d+>/g);if(!n)return d(t);for(var r of n){var i=r.replace(/[<@!>]/g,``),a=valenced.discord.flux.Stores.UserStore.getUser(i);a?.username&&(t=t.replace(r,`@${a.username}`))}return d(t)}function m(e){var t=a(e);if(t)return t;var n=e.messageReference??e.message_reference;if(n){var r=valenced.discord.flux.Stores.ReferencedMessageStore.getMessageByReference(n)?.message;if(r)return r;var i=`messageId`in n?n.messageId??n.message_id:n.message_id,o=`channelId`in n?n.channelId??n.channel_id:n.channel_id,s=valenced.discord.flux.Stores.MessageStore;return typeof i==`string`&&typeof o==`string`?s.getMessage(o,i):void 0}}function h(e){return e?.author??{}}function g(e){return e?.globalName||e?.global_name||e?.username||`Unknown`}function _(e){return String(e?.username||`unknown`).replace(/[^\w.-]/g,``).slice(0,32)||`unknown`}function v(e){try{if(typeof e?.getAvatarURL==`function`)return f(e.getAvatarURL())}catch{}try{var[t]=valenced.modules.finders.lookupModule(valenced.modules.finders.filters.withProps(`getUserAvatarURL`));if(typeof t?.getUserAvatarURL==`function`)return f(t.getUserAvatarURL(e,!1))}catch{}return e?.id&&e?.avatar?`https://cdn.discordapp.com/avatars/${e.id}/${e.avatar}.png?size=512`:`https://cdn.discordapp.com/embed/avatars/0.png?size=512`}function y(e){return e?.channel_id||e?.channelId||e?.channel?.id||null}function b(e){return`${(p(e?.content||``).split(` `).filter(Boolean).slice(0,6).join(` `)||`quote`).replace(/[^\w.-]/g,`_`).slice(0,48)}-${_(h(e))}.png`}function x(e){var t=e.timestamp,n=t&&typeof t==`object`&&`toDate`in t?t.toDate():new Date(t??``);return Number.isNaN(n.getTime())?``:n.toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`,hour12:!1})}function S(e,t,n=!1){var r=h(e),a=t.allowReplies&&n?m(e):void 0,d=a&&h(a),f=a&&t.allowMedia?i(a):[],y=t.allowMedia?i(e):[],b=p(s(e,y));return{media:y,reply:a&&d?{media:f,timestamp:x(a),text:p(s(a,f))||(f.length?``:i(a).length?`[Media]`:`[Message]`),displayName:a.nick||g(d),avatarUrl:v(d),color:/^#[\da-f]{6}$/i.test(a.colorString??d.colorString??``)?a.colorString??d.colorString:`#b5bac1`}:void 0,quote:o(b,t.quotationMarks)||` `,displayName:(e.nick||g(r)).slice(0,64),authorColor:/^#[\da-f]{6}$/i.test(e.colorString??``)?e.colorString:`#f2f3f5`,isBot:!!r.bot,timestamp:x(e),username:`@${_(r)}`,avatarUrl:v(r),grayscale:!!t.grayscale,showWatermark:!!t.showWatermark,watermark:String(t.watermark||``).slice(0,32),quoteFont:`M PLUS Rounded 1c`,canvas:c,fonts:l,spacing:u}}var C=`/*
The MIT License (MIT)
Copyright (c) 2017 Matt DesLauriers

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
OR OTHER DEALINGS IN THE SOFTWARE.


*/
const GIF = (() => { const module = { exports: {} }; const exports = module.exports;
var __defProp = Object.defineProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", {value: true});
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, {get: all[name], enumerable: true});
};

// src/index.js
__markAsModule(exports);
__export(exports, {
  GIFEncoder: () => GIFEncoder,
  applyPalette: () => applyPalette,
  default: () => src_default,
  nearestColor: () => nearestColor,
  nearestColorIndex: () => nearestColorIndex,
  nearestColorIndexWithDistance: () => nearestColorIndexWithDistance,
  prequantize: () => prequantize,
  quantize: () => quantize,
  snapColorsToPalette: () => snapColorsToPalette
});

// src/constants.js
var constants_default = {
  signature: "GIF",
  version: "89a",
  trailer: 59,
  extensionIntroducer: 33,
  applicationExtensionLabel: 255,
  graphicControlExtensionLabel: 249,
  imageSeparator: 44,
  signatureSize: 3,
  versionSize: 3,
  globalColorTableFlagMask: 128,
  colorResolutionMask: 112,
  sortFlagMask: 8,
  globalColorTableSizeMask: 7,
  applicationIdentifierSize: 8,
  applicationAuthCodeSize: 3,
  disposalMethodMask: 28,
  userInputFlagMask: 2,
  transparentColorFlagMask: 1,
  localColorTableFlagMask: 128,
  interlaceFlagMask: 64,
  idSortFlagMask: 32,
  localColorTableSizeMask: 7
};

// src/stream.js
function createStream(initialCapacity = 256) {
  let cursor = 0;
  let contents = new Uint8Array(initialCapacity);
  return {
    get buffer() {
      return contents.buffer;
    },
    reset() {
      cursor = 0;
    },
    bytesView() {
      return contents.subarray(0, cursor);
    },
    bytes() {
      return contents.slice(0, cursor);
    },
    writeByte(byte) {
      expand(cursor + 1);
      contents[cursor] = byte;
      cursor++;
    },
    writeBytes(data, offset = 0, byteLength = data.length) {
      expand(cursor + byteLength);
      for (let i = 0; i < byteLength; i++) {
        contents[cursor++] = data[i + offset];
      }
    },
    writeBytesView(data, offset = 0, byteLength = data.byteLength) {
      expand(cursor + byteLength);
      contents.set(data.subarray(offset, offset + byteLength), cursor);
      cursor += byteLength;
    }
  };
  function expand(newCapacity) {
    var prevCapacity = contents.length;
    if (prevCapacity >= newCapacity)
      return;
    var CAPACITY_DOUBLING_MAX = 1024 * 1024;
    newCapacity = Math.max(newCapacity, prevCapacity * (prevCapacity < CAPACITY_DOUBLING_MAX ? 2 : 1.125) >>> 0);
    if (prevCapacity != 0)
      newCapacity = Math.max(newCapacity, 256);
    const oldContents = contents;
    contents = new Uint8Array(newCapacity);
    if (cursor > 0)
      contents.set(oldContents.subarray(0, cursor), 0);
  }
}

// src/lzwEncode.js
var BITS = 12;
var DEFAULT_HSIZE = 5003;
var MASKS = [
  0,
  1,
  3,
  7,
  15,
  31,
  63,
  127,
  255,
  511,
  1023,
  2047,
  4095,
  8191,
  16383,
  32767,
  65535
];
function lzwEncode(width, height, pixels, colorDepth, outStream = createStream(512), accum = new Uint8Array(256), htab = new Int32Array(DEFAULT_HSIZE), codetab = new Int32Array(DEFAULT_HSIZE)) {
  const hsize = htab.length;
  const initCodeSize = Math.max(2, colorDepth);
  accum.fill(0);
  codetab.fill(0);
  htab.fill(-1);
  let cur_accum = 0;
  let cur_bits = 0;
  const init_bits = initCodeSize + 1;
  const g_init_bits = init_bits;
  let clear_flg = false;
  let n_bits = g_init_bits;
  let maxcode = (1 << n_bits) - 1;
  const ClearCode = 1 << init_bits - 1;
  const EOFCode = ClearCode + 1;
  let free_ent = ClearCode + 2;
  let a_count = 0;
  let ent = pixels[0];
  let hshift = 0;
  for (let fcode = hsize; fcode < 65536; fcode *= 2) {
    ++hshift;
  }
  hshift = 8 - hshift;
  outStream.writeByte(initCodeSize);
  output(ClearCode);
  const length = pixels.length;
  for (let idx = 1; idx < length; idx++) {
    next_block: {
      const c = pixels[idx];
      const fcode = (c << BITS) + ent;
      let i = c << hshift ^ ent;
      if (htab[i] === fcode) {
        ent = codetab[i];
        break next_block;
      }
      const disp = i === 0 ? 1 : hsize - i;
      while (htab[i] >= 0) {
        i -= disp;
        if (i < 0)
          i += hsize;
        if (htab[i] === fcode) {
          ent = codetab[i];
          break next_block;
        }
      }
      output(ent);
      ent = c;
      if (free_ent < 1 << BITS) {
        codetab[i] = free_ent++;
        htab[i] = fcode;
      } else {
        htab.fill(-1);
        free_ent = ClearCode + 2;
        clear_flg = true;
        output(ClearCode);
      }
    }
  }
  output(ent);
  output(EOFCode);
  outStream.writeByte(0);
  return outStream.bytesView();
  function output(code) {
    cur_accum &= MASKS[cur_bits];
    if (cur_bits > 0)
      cur_accum |= code << cur_bits;
    else
      cur_accum = code;
    cur_bits += n_bits;
    while (cur_bits >= 8) {
      accum[a_count++] = cur_accum & 255;
      if (a_count >= 254) {
        outStream.writeByte(a_count);
        outStream.writeBytesView(accum, 0, a_count);
        a_count = 0;
      }
      cur_accum >>= 8;
      cur_bits -= 8;
    }
    if (free_ent > maxcode || clear_flg) {
      if (clear_flg) {
        n_bits = g_init_bits;
        maxcode = (1 << n_bits) - 1;
        clear_flg = false;
      } else {
        ++n_bits;
        maxcode = n_bits === BITS ? 1 << n_bits : (1 << n_bits) - 1;
      }
    }
    if (code == EOFCode) {
      while (cur_bits > 0) {
        accum[a_count++] = cur_accum & 255;
        if (a_count >= 254) {
          outStream.writeByte(a_count);
          outStream.writeBytesView(accum, 0, a_count);
          a_count = 0;
        }
        cur_accum >>= 8;
        cur_bits -= 8;
      }
      if (a_count > 0) {
        outStream.writeByte(a_count);
        outStream.writeBytesView(accum, 0, a_count);
        a_count = 0;
      }
    }
  }
}
var lzwEncode_default = lzwEncode;

// src/rgb-packing.js
function rgb888_to_rgb565(r, g, b) {
  return r << 8 & 63488 | g << 2 & 992 | b >> 3;
}
function rgba8888_to_rgba4444(r, g, b, a) {
  return r >> 4 | g & 240 | (b & 240) << 4 | (a & 240) << 8;
}
function rgb888_to_rgb444(r, g, b) {
  return r >> 4 << 8 | g & 240 | b >> 4;
}

// src/pnnquant2.js
function clamp(value, min, max) {
  return value < min ? min : value > max ? max : value;
}
function sqr(value) {
  return value * value;
}
function find_nn(bins, idx, hasAlpha) {
  var nn = 0;
  var err = 1e100;
  const bin1 = bins[idx];
  const n1 = bin1.cnt;
  const wa = bin1.ac;
  const wr = bin1.rc;
  const wg = bin1.gc;
  const wb = bin1.bc;
  for (var i = bin1.fw; i != 0; i = bins[i].fw) {
    const bin = bins[i];
    const n2 = bin.cnt;
    const nerr2 = n1 * n2 / (n1 + n2);
    if (nerr2 >= err)
      continue;
    var nerr = 0;
    if (hasAlpha) {
      nerr += nerr2 * sqr(bin.ac - wa);
      if (nerr >= err)
        continue;
    }
    nerr += nerr2 * sqr(bin.rc - wr);
    if (nerr >= err)
      continue;
    nerr += nerr2 * sqr(bin.gc - wg);
    if (nerr >= err)
      continue;
    nerr += nerr2 * sqr(bin.bc - wb);
    if (nerr >= err)
      continue;
    err = nerr;
    nn = i;
  }
  bin1.err = err;
  bin1.nn = nn;
}
function create_bin() {
  return {
    ac: 0,
    rc: 0,
    gc: 0,
    bc: 0,
    cnt: 0,
    nn: 0,
    fw: 0,
    bk: 0,
    tm: 0,
    mtm: 0,
    err: 0
  };
}
function create_bin_list(data, format) {
  const bincount = format === "rgb444" ? 4096 : 65536;
  const bins = new Array(bincount);
  const size = data.length;
  if (format === "rgba4444") {
    for (let i = 0; i < size; ++i) {
      const color = data[i];
      const a = color >> 24 & 255;
      const b = color >> 16 & 255;
      const g = color >> 8 & 255;
      const r = color & 255;
      const index = rgba8888_to_rgba4444(r, g, b, a);
      let bin = index in bins ? bins[index] : bins[index] = create_bin();
      bin.rc += r;
      bin.gc += g;
      bin.bc += b;
      bin.ac += a;
      bin.cnt++;
    }
  } else if (format === "rgb444") {
    for (let i = 0; i < size; ++i) {
      const color = data[i];
      const b = color >> 16 & 255;
      const g = color >> 8 & 255;
      const r = color & 255;
      const index = rgb888_to_rgb444(r, g, b);
      let bin = index in bins ? bins[index] : bins[index] = create_bin();
      bin.rc += r;
      bin.gc += g;
      bin.bc += b;
      bin.cnt++;
    }
  } else {
    for (let i = 0; i < size; ++i) {
      const color = data[i];
      const b = color >> 16 & 255;
      const g = color >> 8 & 255;
      const r = color & 255;
      const index = rgb888_to_rgb565(r, g, b);
      let bin = index in bins ? bins[index] : bins[index] = create_bin();
      bin.rc += r;
      bin.gc += g;
      bin.bc += b;
      bin.cnt++;
    }
  }
  return bins;
}
function quantize(rgba, maxColors, opts = {}) {
  const {
    format = "rgb565",
    clearAlpha = true,
    clearAlphaColor = 0,
    clearAlphaThreshold = 0,
    oneBitAlpha = false
  } = opts;
  if (!rgba || !rgba.buffer) {
    throw new Error("quantize() expected RGBA Uint8Array data");
  }
  if (!(rgba instanceof Uint8Array) && !(rgba instanceof Uint8ClampedArray)) {
    throw new Error("quantize() expected RGBA Uint8Array data");
  }
  const data = new Uint32Array(rgba.buffer);
  let useSqrt = opts.useSqrt !== false;
  const hasAlpha = format === "rgba4444";
  const bins = create_bin_list(data, format);
  const bincount = bins.length;
  const bincountMinusOne = bincount - 1;
  const heap = new Uint32Array(bincount + 1);
  var maxbins = 0;
  for (var i = 0; i < bincount; ++i) {
    const bin = bins[i];
    if (bin != null) {
      var d = 1 / bin.cnt;
      if (hasAlpha)
        bin.ac *= d;
      bin.rc *= d;
      bin.gc *= d;
      bin.bc *= d;
      bins[maxbins++] = bin;
    }
  }
  if (sqr(maxColors) / maxbins < 0.022) {
    useSqrt = false;
  }
  var i = 0;
  for (; i < maxbins - 1; ++i) {
    bins[i].fw = i + 1;
    bins[i + 1].bk = i;
    if (useSqrt)
      bins[i].cnt = Math.sqrt(bins[i].cnt);
  }
  if (useSqrt)
    bins[i].cnt = Math.sqrt(bins[i].cnt);
  var h, l, l2;
  for (i = 0; i < maxbins; ++i) {
    find_nn(bins, i, false);
    var err = bins[i].err;
    for (l = ++heap[0]; l > 1; l = l2) {
      l2 = l >> 1;
      if (bins[h = heap[l2]].err <= err)
        break;
      heap[l] = h;
    }
    heap[l] = i;
  }
  var extbins = maxbins - maxColors;
  for (i = 0; i < extbins; ) {
    var tb;
    for (; ; ) {
      var b1 = heap[1];
      tb = bins[b1];
      if (tb.tm >= tb.mtm && bins[tb.nn].mtm <= tb.tm)
        break;
      if (tb.mtm == bincountMinusOne)
        b1 = heap[1] = heap[heap[0]--];
      else {
        find_nn(bins, b1, false);
        tb.tm = i;
      }
      var err = bins[b1].err;
      for (l = 1; (l2 = l + l) <= heap[0]; l = l2) {
        if (l2 < heap[0] && bins[heap[l2]].err > bins[heap[l2 + 1]].err)
          l2++;
        if (err <= bins[h = heap[l2]].err)
          break;
        heap[l] = h;
      }
      heap[l] = b1;
    }
    var nb = bins[tb.nn];
    var n1 = tb.cnt;
    var n2 = nb.cnt;
    var d = 1 / (n1 + n2);
    if (hasAlpha)
      tb.ac = d * (n1 * tb.ac + n2 * nb.ac);
    tb.rc = d * (n1 * tb.rc + n2 * nb.rc);
    tb.gc = d * (n1 * tb.gc + n2 * nb.gc);
    tb.bc = d * (n1 * tb.bc + n2 * nb.bc);
    tb.cnt += nb.cnt;
    tb.mtm = ++i;
    bins[nb.bk].fw = nb.fw;
    bins[nb.fw].bk = nb.bk;
    nb.mtm = bincountMinusOne;
  }
  let palette = [];
  var k = 0;
  for (i = 0; ; ++k) {
    let r = clamp(Math.round(bins[i].rc), 0, 255);
    let g = clamp(Math.round(bins[i].gc), 0, 255);
    let b = clamp(Math.round(bins[i].bc), 0, 255);
    let a = 255;
    if (hasAlpha) {
      a = clamp(Math.round(bins[i].ac), 0, 255);
      if (oneBitAlpha) {
        const threshold = typeof oneBitAlpha === "number" ? oneBitAlpha : 127;
        a = a <= threshold ? 0 : 255;
      }
      if (clearAlpha && a <= clearAlphaThreshold) {
        r = g = b = clearAlphaColor;
        a = 0;
      }
    }
    const color = hasAlpha ? [r, g, b, a] : [r, g, b];
    const exists = existsInPalette(palette, color);
    if (!exists)
      palette.push(color);
    if ((i = bins[i].fw) == 0)
      break;
  }
  return palette;
}
function existsInPalette(palette, color) {
  for (let i = 0; i < palette.length; i++) {
    const p = palette[i];
    let matchesRGB = p[0] === color[0] && p[1] === color[1] && p[2] === color[2];
    let matchesAlpha = p.length >= 4 && color.length >= 4 ? p[3] === color[3] : true;
    if (matchesRGB && matchesAlpha)
      return true;
  }
  return false;
}

// src/color.js
function euclideanDistanceSquared(a, b) {
  var sum = 0;
  var n;
  for (n = 0; n < a.length; n++) {
    const dx = a[n] - b[n];
    sum += dx * dx;
  }
  return sum;
}

// src/palettize.js
function roundStep(byte, step) {
  return step > 1 ? Math.round(byte / step) * step : byte;
}
function prequantize(rgba, {roundRGB = 5, roundAlpha = 10, oneBitAlpha = null} = {}) {
  const data = new Uint32Array(rgba.buffer);
  for (let i = 0; i < data.length; i++) {
    const color = data[i];
    let a = color >> 24 & 255;
    let b = color >> 16 & 255;
    let g = color >> 8 & 255;
    let r = color & 255;
    a = roundStep(a, roundAlpha);
    if (oneBitAlpha) {
      const threshold = typeof oneBitAlpha === "number" ? oneBitAlpha : 127;
      a = a <= threshold ? 0 : 255;
    }
    r = roundStep(r, roundRGB);
    g = roundStep(g, roundRGB);
    b = roundStep(b, roundRGB);
    data[i] = a << 24 | b << 16 | g << 8 | r << 0;
  }
}
function applyPalette(rgba, palette, format = "rgb565") {
  if (!rgba || !rgba.buffer) {
    throw new Error("quantize() expected RGBA Uint8Array data");
  }
  if (!(rgba instanceof Uint8Array) && !(rgba instanceof Uint8ClampedArray)) {
    throw new Error("quantize() expected RGBA Uint8Array data");
  }
  if (palette.length > 256) {
    throw new Error("applyPalette() only works with 256 colors or less");
  }
  const data = new Uint32Array(rgba.buffer);
  const length = data.length;
  const bincount = format === "rgb444" ? 4096 : 65536;
  const index = new Uint8Array(length);
  const cache = new Array(bincount);
  const hasAlpha = format === "rgba4444";
  if (format === "rgba4444") {
    for (let i = 0; i < length; i++) {
      const color = data[i];
      const a = color >> 24 & 255;
      const b = color >> 16 & 255;
      const g = color >> 8 & 255;
      const r = color & 255;
      const key = rgba8888_to_rgba4444(r, g, b, a);
      const idx = key in cache ? cache[key] : cache[key] = nearestColorIndexRGBA(r, g, b, a, palette);
      index[i] = idx;
    }
  } else {
    const rgb888_to_key = format === "rgb444" ? rgb888_to_rgb444 : rgb888_to_rgb565;
    for (let i = 0; i < length; i++) {
      const color = data[i];
      const b = color >> 16 & 255;
      const g = color >> 8 & 255;
      const r = color & 255;
      const key = rgb888_to_key(r, g, b);
      const idx = key in cache ? cache[key] : cache[key] = nearestColorIndexRGB(r, g, b, palette);
      index[i] = idx;
    }
  }
  return index;
}
function nearestColorIndexRGBA(r, g, b, a, palette) {
  let k = 0;
  let mindist = 1e100;
  for (let i = 0; i < palette.length; i++) {
    const px2 = palette[i];
    const a2 = px2[3];
    let curdist = sqr2(a2 - a);
    if (curdist > mindist)
      continue;
    const r2 = px2[0];
    curdist += sqr2(r2 - r);
    if (curdist > mindist)
      continue;
    const g2 = px2[1];
    curdist += sqr2(g2 - g);
    if (curdist > mindist)
      continue;
    const b2 = px2[2];
    curdist += sqr2(b2 - b);
    if (curdist > mindist)
      continue;
    mindist = curdist;
    k = i;
  }
  return k;
}
function nearestColorIndexRGB(r, g, b, palette) {
  let k = 0;
  let mindist = 1e100;
  for (let i = 0; i < palette.length; i++) {
    const px2 = palette[i];
    const r2 = px2[0];
    let curdist = sqr2(r2 - r);
    if (curdist > mindist)
      continue;
    const g2 = px2[1];
    curdist += sqr2(g2 - g);
    if (curdist > mindist)
      continue;
    const b2 = px2[2];
    curdist += sqr2(b2 - b);
    if (curdist > mindist)
      continue;
    mindist = curdist;
    k = i;
  }
  return k;
}
function snapColorsToPalette(palette, knownColors, threshold = 5) {
  if (!palette.length || !knownColors.length)
    return;
  const paletteRGB = palette.map((p) => p.slice(0, 3));
  const thresholdSq = threshold * threshold;
  const dim = palette[0].length;
  for (let i = 0; i < knownColors.length; i++) {
    let color = knownColors[i];
    if (color.length < dim) {
      color = [color[0], color[1], color[2], 255];
    } else if (color.length > dim) {
      color = color.slice(0, 3);
    } else {
      color = color.slice();
    }
    const r = nearestColorIndexWithDistance(paletteRGB, color.slice(0, 3), euclideanDistanceSquared);
    const idx = r[0];
    const distanceSq = r[1];
    if (distanceSq > 0 && distanceSq <= thresholdSq) {
      palette[idx] = color;
    }
  }
}
function sqr2(a) {
  return a * a;
}
function nearestColorIndex(colors, pixel, distanceFn = euclideanDistanceSquared) {
  let minDist = Infinity;
  let minDistIndex = -1;
  for (let j = 0; j < colors.length; j++) {
    const paletteColor = colors[j];
    const dist = distanceFn(pixel, paletteColor);
    if (dist < minDist) {
      minDist = dist;
      minDistIndex = j;
    }
  }
  return minDistIndex;
}
function nearestColorIndexWithDistance(colors, pixel, distanceFn = euclideanDistanceSquared) {
  let minDist = Infinity;
  let minDistIndex = -1;
  for (let j = 0; j < colors.length; j++) {
    const paletteColor = colors[j];
    const dist = distanceFn(pixel, paletteColor);
    if (dist < minDist) {
      minDist = dist;
      minDistIndex = j;
    }
  }
  return [minDistIndex, minDist];
}
function nearestColor(colors, pixel, distanceFn = euclideanDistanceSquared) {
  return colors[nearestColorIndex(colors, pixel, distanceFn)];
}

// src/index.js
function GIFEncoder(opt = {}) {
  const {initialCapacity = 4096, auto = true} = opt;
  const stream = createStream(initialCapacity);
  const HSIZE = 5003;
  const accum = new Uint8Array(256);
  const htab = new Int32Array(HSIZE);
  const codetab = new Int32Array(HSIZE);
  let hasInit = false;
  return {
    reset() {
      stream.reset();
      hasInit = false;
    },
    finish() {
      stream.writeByte(constants_default.trailer);
    },
    bytes() {
      return stream.bytes();
    },
    bytesView() {
      return stream.bytesView();
    },
    get buffer() {
      return stream.buffer;
    },
    get stream() {
      return stream;
    },
    writeHeader,
    writeFrame(index, width, height, opts = {}) {
      const {
        transparent = false,
        transparentIndex = 0,
        delay = 0,
        palette = null,
        repeat = 0,
        colorDepth = 8,
        dispose = -1,
        x = 0,
        y = 0
      } = opts;
      let first = false;
      if (auto) {
        if (!hasInit) {
          first = true;
          writeHeader();
          hasInit = true;
        }
      } else {
        first = Boolean(opts.first);
      }
      width = Math.max(0, Math.floor(width));
      height = Math.max(0, Math.floor(height));
      if (first) {
        if (!palette) {
          throw new Error("First frame must include a { palette } option");
        }
        encodeLogicalScreenDescriptor(stream, width, height, palette, colorDepth);
        encodeColorTable(stream, palette);
        if (repeat >= 0) {
          encodeNetscapeExt(stream, repeat);
        }
      }
      const delayTime = Math.round(delay / 10);
      encodeGraphicControlExt(stream, dispose, delayTime, transparent, transparentIndex);
      const useLocalColorTable = Boolean(palette) && !first;
      encodeImageDescriptor(stream, width, height, useLocalColorTable ? palette : null, x, y);
      if (useLocalColorTable)
        encodeColorTable(stream, palette);
      encodePixels(stream, index, width, height, colorDepth, accum, htab, codetab);
    }
  };
  function writeHeader() {
    writeUTFBytes(stream, "GIF89a");
  }
}
function encodeGraphicControlExt(stream, dispose, delay, transparent, transparentIndex) {
  stream.writeByte(33);
  stream.writeByte(249);
  stream.writeByte(4);
  if (transparentIndex < 0) {
    transparentIndex = 0;
    transparent = false;
  }
  var transp, disp;
  if (!transparent) {
    transp = 0;
    disp = 0;
  } else {
    transp = 1;
    disp = 2;
  }
  if (dispose >= 0) {
    disp = dispose & 7;
  }
  disp <<= 2;
  const userInput = 0;
  stream.writeByte(0 | disp | userInput | transp);
  writeUInt16(stream, delay);
  stream.writeByte(transparentIndex || 0);
  stream.writeByte(0);
}
function encodeLogicalScreenDescriptor(stream, width, height, palette, colorDepth = 8) {
  const globalColorTableFlag = 1;
  const sortFlag = 0;
  const globalColorTableSize = colorTableSize(palette.length) - 1;
  const fields = globalColorTableFlag << 7 | colorDepth - 1 << 4 | sortFlag << 3 | globalColorTableSize;
  const backgroundColorIndex = 0;
  const pixelAspectRatio = 0;
  writeUInt16(stream, width);
  writeUInt16(stream, height);
  stream.writeBytes([fields, backgroundColorIndex, pixelAspectRatio]);
}
function encodeNetscapeExt(stream, repeat) {
  stream.writeByte(33);
  stream.writeByte(255);
  stream.writeByte(11);
  writeUTFBytes(stream, "NETSCAPE2.0");
  stream.writeByte(3);
  stream.writeByte(1);
  writeUInt16(stream, repeat);
  stream.writeByte(0);
}
function encodeColorTable(stream, palette) {
  const colorTableLength = 1 << colorTableSize(palette.length);
  for (let i = 0; i < colorTableLength; i++) {
    let color = [0, 0, 0];
    if (i < palette.length) {
      color = palette[i];
    }
    stream.writeByte(color[0]);
    stream.writeByte(color[1]);
    stream.writeByte(color[2]);
  }
}
function encodeImageDescriptor(stream, width, height, localPalette, x, y) {
  stream.writeByte(44);
  writeUInt16(stream, x);
  writeUInt16(stream, y);
  writeUInt16(stream, width);
  writeUInt16(stream, height);
  if (localPalette) {
    const interlace = 0;
    const sorted = 0;
    const palSize = colorTableSize(localPalette.length) - 1;
    stream.writeByte(128 | interlace | sorted | 0 | palSize);
  } else {
    stream.writeByte(0);
  }
}
function encodePixels(stream, index, width, height, colorDepth = 8, accum, htab, codetab) {
  lzwEncode_default(width, height, index, colorDepth, stream, accum, htab, codetab);
}
function writeUInt16(stream, short) {
  stream.writeByte(short & 255);
  stream.writeByte(short >> 8 & 255);
}
function writeUTFBytes(stream, text) {
  for (var i = 0; i < text.length; i++) {
    stream.writeByte(text.charCodeAt(i));
  }
}
function colorTableSize(length) {
  return Math.max(Math.ceil(Math.log2(length)), 1);
}
var src_default = GIFEncoder;

return module.exports; })();`,w=`
async function fetchMedia(url) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 20000);
    try {
        const response = await fetch(url, { signal: controller.signal });
        if (!response.ok) throw new Error("Could not download quote media.");
        const blob = await response.blob();
        if (blob.size > 30 * 1024 * 1024) throw new Error("This media is too large to quote (30 MB maximum).");
        return blob;
    } finally { clearTimeout(timer); }
}
function mediaEvent(target, event, action) {
    return new Promise((resolve, reject) => {
        const timer = setTimeout(() => finish(new Error("Media decoding timed out.")), 15000);
        const success = () => finish();
        const error = () => finish(new Error("Could not decode quote media."));
        function finish(failure) {
            clearTimeout(timer);
            target.removeEventListener(event, success);
            target.removeEventListener('error', error);
            failure ? reject(failure) : resolve();
        }
        target.addEventListener(event, success, { once: true });
        target.addEventListener('error', error, { once: true });
        action();
    });
}
async function loadMedia(item) {
    const blob = await fetchMedia(item.url);
    if (item.kind === 'video') {
        const url = URL.createObjectURL(blob);
        const video = document.createElement('video');
        video.muted = true;
        video.preload = 'auto';
        video.playsInline = true;
        try {
            await mediaEvent(video, 'loadeddata', () => { video.src = url; video.load(); });
            const duration = video.duration * 1000;
            if (!Number.isFinite(duration) || duration <= 0 || duration > 30000) throw new Error("Animated quotes support clips up to 30 seconds.");
            return {
                width: video.videoWidth, height: video.videoHeight, duration,
                boundaries: Array.from({ length: Math.ceil(duration / 50) }, (_, i) => i * 50),
                async frameAt(time) {
                    const target = Math.min((time % duration) / 1000, video.duration - 0.001);
                    if (Math.abs(video.currentTime - target) > 0.001) await mediaEvent(video, 'seeked', () => { video.currentTime = target; });
                    return { image: video, close() {} };
                },
                close() { video.removeAttribute('src'); video.load(); URL.revokeObjectURL(url); },
            };
        } catch (error) { video.removeAttribute('src'); video.load(); URL.revokeObjectURL(url); throw error; }
    }
    const bytes = await blob.arrayBuffer();
    const signature = new Uint8Array(bytes, 0, Math.min(bytes.byteLength, 12));
    const type = signature[0] === 71 && signature[1] === 73 && signature[2] === 70 ? 'image/gif'
        : signature[0] === 82 && signature[8] === 87 ? 'image/webp'
        : blob.type.split(';')[0];
    if (typeof ImageDecoder !== 'undefined' && await ImageDecoder.isTypeSupported(type)) {
        const decoder = new ImageDecoder({ data: bytes, type, preferAnimation: true });
        try {
            await decoder.tracks.ready;
            await decoder.completed;
            const count = decoder.tracks.selectedTrack.frameCount;
            if (count > 600) throw new Error("This animation has too many frames to quote (600 maximum).");
            const boundaries = [];
            let duration = 0, width = 0, height = 0;
            for (let i = 0; i < count; i++) {
                const { image } = await decoder.decode({ frameIndex: i });
                width = image.displayWidth; height = image.displayHeight;
                boundaries.push(duration);
                duration += Math.max(20, (image.duration || 100000) / 1000);
                image.close();
            }
            if (count > 1 && duration > 30000) throw new Error("Animated quotes support clips up to 30 seconds.");
            return {
                width, height, duration: count > 1 ? duration : 0, boundaries,
                async frameAt(time) {
                    const local = time % duration;
                    let index = 0;
                    while (index + 1 < count && boundaries[index + 1] <= local) index++;
                    const { image } = await decoder.decode({ frameIndex: index });
                    return { image, close() { image.close(); } };
                },
                close() { decoder.close(); },
            };
        } catch (error) { decoder.close(); throw error; }
    }
    if (type === 'image/gif' || type === 'image/webp') throw new Error("Update Android System WebView to quote animated images.");
    const url = URL.createObjectURL(blob);
    try {
        const image = new Image();
        await mediaEvent(image, 'load', () => { image.src = url; });
        return { width: image.naturalWidth, height: image.naturalHeight, duration: 0, boundaries: [0], async frameAt() { return { image, close() {} }; }, close() {} };
    } finally { URL.revokeObjectURL(url); }
}
async function exportMedia(canvas, media, rectangles, renderId) {
    const ctx = canvas.getContext('2d');
    const duration = Math.max(0, ...media.map(item => item.duration));
    const times = new Set([0]);
    for (const item of media) {
        if (!item.duration) continue;
        for (let loop = 0; loop < duration; loop += item.duration) {
            for (const boundary of item.boundaries) if (loop + boundary < duration) times.add(loop + boundary);
        }
    }
    const timeline = Array.from(times).sort((a, b) => a - b);
    if (timeline.length > 600) throw new Error("Combined animation exceeds 600 frames. Quote fewer animated attachments.");
    const gif = duration ? GIF.GIFEncoder() : null;
    let palette;
    let indexed;
    const lastFrames = media.map(() => -1);
    const frameCaches = media.map(() => new Map());
    let cachedBytes = 0;
    if (gif) {
        await Promise.all(media.map(async (item, m) => {
            const frame = await item.frameAt(0);
            const rect = rectangles[m];
            try {
                ctx.fillStyle = '#000';
                ctx.fillRect(rect.x, rect.y, rect.width, rect.height);
                ctx.drawImage(frame.image, rect.x, rect.y, rect.width, rect.height);
            } finally { frame.close(); }
        }));
        post({ type: 'preview', renderId, dataUrl: canvas.toDataURL('image/png'), width: canvas.width, height: canvas.height });
        // One palette for the entire GIF keeps all static pixels identical between frames.
        const sample = document.createElement('canvas');
        sample.width = sample.height = 128;
        const sampleContext = sample.getContext('2d');
        sampleContext.drawImage(canvas, 0, 0, 128, 128);
        const chunks = [sampleContext.getImageData(0, 0, 128, 128).data];
        sample.width = sample.height = 32;
        const sampleCount = Math.min(12, timeline.length);
        for (let index = 0; index < sampleCount; index++) {
            const time = timeline[Math.round(index * (timeline.length - 1) / Math.max(1, sampleCount - 1))];
            await Promise.all(media.map(async item => {
                if (!item.duration && index) return;
                const frame = await item.frameAt(time);
                try {
                    sampleContext.fillStyle = '#000';
                    sampleContext.fillRect(0, 0, 32, 32);
                    sampleContext.drawImage(frame.image, 0, 0, 32, 32);
                    chunks.push(sampleContext.getImageData(0, 0, 32, 32).data);
                } finally { frame.close(); }
            }));
            post({ type: 'progress', renderId, message: 'Preparing animation ' + Math.round((index + 1) / sampleCount * 100) + '%' });
            await new Promise(resolve => setTimeout(resolve, 0));
        }
        const samples = new Uint8Array(chunks.reduce((size, chunk) => size + chunk.length, 0));
        let offset = 0;
        for (const chunk of chunks) { samples.set(chunk, offset); offset += chunk.length; }
        palette = GIF.quantize(samples, 256);
    }
    for (let index = 0; index < timeline.length; index++) {
        const changed = [];
        await Promise.all(media.map(async (item, m) => {
            const local = item.duration ? timeline[index] % item.duration : 0;
            let frameIndex = 0;
            while (frameIndex + 1 < item.boundaries.length && item.boundaries[frameIndex + 1] <= local) frameIndex++;
            if (gif && index === 0) { lastFrames[m] = frameIndex; changed.push(m); return; }
            if (lastFrames[m] === frameIndex) return;
            lastFrames[m] = frameIndex;
            changed.push(m);
            if (frameCaches[m].has(frameIndex)) return;
            const rect = rectangles[m];
            const frame = await item.frameAt(item.boundaries[frameIndex]);
            try {
                ctx.fillStyle = '#000';
                ctx.fillRect(rect.x, rect.y, rect.width, rect.height);
                ctx.drawImage(frame.image, rect.x, rect.y, rect.width, rect.height);
            } finally { frame.close(); }
        }));
        if (gif) {
            const firstFrame = !indexed;
            if (firstFrame) indexed = GIF.applyPalette(ctx.getImageData(0, 0, canvas.width, canvas.height).data, palette);
            for (const m of changed) {
                if (!media[m].duration) continue;
                const rect = rectangles[m];
                let pixels = frameCaches[m].get(lastFrames[m]);
                if (!pixels) {
                    if (firstFrame) {
                        pixels = new Uint8Array(rect.width * rect.height);
                        for (let row = 0; row < rect.height; row++) {
                            const start = (rect.y + row) * canvas.width + rect.x;
                            pixels.set(indexed.subarray(start, start + rect.width), row * rect.width);
                        }
                    } else {
                        pixels = GIF.applyPalette(ctx.getImageData(rect.x, rect.y, rect.width, rect.height).data, palette);
                    }
                    // Bound memory while reusing frames when a shorter animation loops.
                    if (cachedBytes + pixels.byteLength <= 32 * 1024 * 1024) {
                        frameCaches[m].set(lastFrames[m], pixels);
                        cachedBytes += pixels.byteLength;
                    }
                }
                for (let row = 0; row < rect.height; row++) {
                    indexed.set(pixels.subarray(row * rect.width, (row + 1) * rect.width), (rect.y + row) * canvas.width + rect.x);
                }
            }
            let framePixels = indexed, x = 0, y = 0, width = canvas.width, height = canvas.height;
            if (index) {
                const regions = changed.map(m => rectangles[m]);
                x = regions.length ? Math.min(...regions.map(rect => rect.x)) : 0;
                y = regions.length ? Math.min(...regions.map(rect => rect.y)) : 0;
                width = regions.length ? Math.max(...regions.map(rect => rect.x + rect.width)) - x : 1;
                height = regions.length ? Math.max(...regions.map(rect => rect.y + rect.height)) - y : 1;
                framePixels = new Uint8Array(width * height);
                for (let row = 0; row < height; row++) {
                    const start = (y + row) * canvas.width + x;
                    framePixels.set(indexed.subarray(start, start + width), row * width);
                }
            }
            gif.writeFrame(framePixels, width, height, { x, y, dispose: 1, palette: index ? undefined : palette, delay: (timeline[index + 1] ?? duration) - timeline[index], repeat: 0 });
            if (gif.bytesView().length > 25 * 1024 * 1024) throw new Error("The animated quote exceeds 25 MB. Try fewer attachments or less text.");
            post({ type: 'progress', renderId, message: 'Rendering animation ' + Math.round((index + 1) / timeline.length * 100) + '%' });
            await new Promise(resolve => setTimeout(resolve, 0));
        }
    }
    if (!gif) return canvas.toDataURL('image/png');
    gif.finish();
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(new Error('Could not export animated quote.'));
        reader.readAsDataURL(new Blob([gif.bytes()], { type: 'image/gif' }));
    });
}
`;function T(e){var t=JSON.stringify(e).replace(/<\/script/gi,`<\\/script`);return`<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<style>
${e.reply?`@font-face { font-family: 'gg sans'; font-weight: 400; src: url('file:///android_asset/fonts/ggsans-Normal.ttf'); } @font-face { font-family: 'gg sans'; font-weight: 600; src: url('file:///android_asset/fonts/ggsans-Semibold.ttf'); }`:`@import url('https://fonts.googleapis.com/css2?family=M+PLUS+Rounded+1c:wght@300&display=swap');`}
html, body {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
    background: #000;
    overflow: hidden;
}
canvas {
    width: 100%;
    height: 100%;
    display: block;
}
</style>
</head>
<body>
<canvas id="q" width="1200" height="600"></canvas>
<script>
const payload = ${t};
${e.media?.length||e.reply?.media?.length?`${C}\n${w}`:``}

function post(data) {
    try {
        window.ReactNativeWebView.postMessage(JSON.stringify(data));
    } catch {}
}

async function waitForFonts(font) {
    try {
        await Promise.race([
            Promise.all([
                document.fonts.load("300 42px '" + font + "'"),
                document.fonts.load("italic 300 26px '" + font + "'"),
                document.fonts.ready,
            ]),
            new Promise(resolve => setTimeout(resolve, 4000)),
        ]);
    } catch {}
}

function calculateTextLines(ctx, text, fontSize, font, maxWidth, firstWidth = maxWidth) {
    ctx.font = "300 " + fontSize + "px '" + font + "', sans-serif";
    const lines = [];
    const segmenter = typeof Intl.Segmenter === "function" ? new Intl.Segmenter(undefined, { granularity: "grapheme" }) : null;
    for (const paragraph of String(text || "").split("\\n")) {
        let line = "";
        for (const word of paragraph.split(/\\s+/).filter(Boolean)) {
            const candidate = line ? line + " " + word : word;
            if (ctx.measureText(candidate).width <= (lines.length ? maxWidth : firstWidth)) { line = candidate; continue; }
            if (line) { lines.push(line); line = ""; }
            const units = segmenter ? Array.from(segmenter.segment(word), part => part.segment) : Array.from(word);
            for (const unit of units) {
                if (line && ctx.measureText(line + unit).width > (lines.length ? maxWidth : firstWidth)) { lines.push(line); line = ""; }
                line += unit;
            }
        }
        lines.push(line);
    }

    return lines;
}

function calculateFont(ctx, quote, font, cfg, fs, sp) {
    let fontSize = fs.initial;
    while (fontSize >= fs.minimum) {
        const lines = calculateTextLines(ctx, quote, fontSize, font, cfg.quoteAreaWidth);
        const lineHeight = fontSize * fs.lineHeightMultiplier;
        const authorFontSize = Math.max(fs.authorMinimum, fontSize * fs.authorMultiplier);
        const usernameFontSize = Math.max(fs.usernameMinimum, fontSize * fs.usernameMultiplier);
        const totalHeight = (lines.length * lineHeight) + sp.authorTop + authorFontSize + sp.username + usernameFontSize;
        if (totalHeight <= cfg.maxContentHeight) {
            return { lines, fontSize, lineHeight, authorFontSize, usernameFontSize, totalHeight };
        }
        fontSize -= fs.decrement;
    }

    const lines = calculateTextLines(ctx, quote, fs.minimum, font, cfg.quoteAreaWidth);
    const lineHeight = fs.minimum * fs.lineHeightMultiplier;
    return {
        lines,
        fontSize: fs.minimum,
        lineHeight,
        authorFontSize: fs.authorMinimum,
        usernameFontSize: fs.usernameMinimum,
        totalHeight: (lines.length * lineHeight) + sp.authorTop + fs.authorMinimum + sp.username + fs.usernameMinimum,
    };
}

async function loadAvatar(url) {
    // Time-cap the fetch so a stalled connection surfaces as an error
    // instead of leaving the preview stuck on "Generating..." forever.
    const response = await Promise.race([
        fetch(url),
        new Promise((_, reject) => setTimeout(() => reject(new Error("Avatar request timed out.")), 10000)),
    ]);
    if (!response.ok) throw new Error("Failed to fetch avatar image.");
    const blob = await response.blob();
    const blobUrl = URL.createObjectURL(blob);

    try {
        return await new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = () => resolve(img);
            img.onerror = () => reject(new Error("Failed to load avatar image."));
            img.src = blobUrl;
        });
    } finally {
        URL.revokeObjectURL(blobUrl);
    }
}

async function render() {
    const media = [];
    try {
    const replyMediaCount = payload.reply?.media?.length || 0;
    const loaded = await Promise.allSettled([...(payload.reply?.media || []), ...(payload.media || [])].map(item => loadMedia(item)));
    for (const result of loaded) if (result.status === 'fulfilled') media.push(result.value);
    const failure = loaded.find(result => result.status === 'rejected');
    if (failure) throw failure.reason;
    const cfg = payload.reply ? { ...payload.canvas, width: 1200 } : payload.canvas;
    const fs = payload.fonts;
    const sp = payload.spacing;
    const quoteFont = payload.reply ? "gg sans" : payload.quoteFont || "M PLUS Rounded 1c";

    if (payload.reply) await Promise.all([document.fonts.load("400 32px 'gg sans'"), document.fonts.load("600 30px 'gg sans'")]);
    else await waitForFonts(quoteFont);

    const canvas = document.getElementById("q");
    canvas.width = cfg.width;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Canvas context unavailable.");
    const quote = String(payload.quote || " ");
    const reply = payload.reply;
    const areaX = reply ? 24 : cfg.quoteAreaX;
    let areaWidth = reply ? cfg.width - 48 : cfg.quoteAreaWidth;
    let blockWidth = areaWidth;
    if (reply) {
        ctx.font = "400 32px 'gg sans', sans-serif";
        const bodyWidth = Math.max(...quote.split('\\n').map(line => ctx.measureText(line).width)) + 108;
        ctx.font = "600 24px 'gg sans', sans-serif";
        const referenceNameWidth = ctx.measureText(reply.displayName).width;
        ctx.font = "400 24px 'gg sans', sans-serif";
        const referenceHeaderWidth = referenceNameWidth + 158 + (reply.timestamp ? ctx.measureText(reply.timestamp).width + 18 : 0);
        const referenceWidth = referenceHeaderWidth + Math.max(...reply.text.split('\\n').map(line => ctx.measureText(line).width));
        ctx.font = "600 30px 'gg sans', sans-serif";
        const headerWidth = ctx.measureText(payload.displayName).width + 108 + (payload.isBot ? 190 : 120);
        blockWidth = Math.max(headerWidth, referenceHeaderWidth + 120, Math.min(areaWidth, Math.max(bodyWidth, referenceWidth)));
        areaWidth = blockWidth;
    }
    if (reply) {
        cfg.width = Math.ceil(blockWidth + areaX * 2);
        canvas.width = cfg.width;
    }
    const blockX = reply ? areaX : areaX + (areaWidth - blockWidth) / 2;
    const contentWidth = blockWidth - (reply ? 108 : 0);
    const calculation = calculateFont(ctx, quote, quoteFont, cfg, fs, sp);
    const messageLines = reply ? (quote.trim() ? calculateTextLines(ctx, quote, 32, 'gg sans', contentWidth) : []) : calculation.lines;
    ctx.font = "600 24px 'gg sans', sans-serif";
    const replyNameWidth = reply ? ctx.measureText(reply.displayName).width : 0;
    ctx.font = "400 24px 'gg sans', sans-serif";
    const replyTimestampWidth = reply?.timestamp ? ctx.measureText(reply.timestamp).width + 18 : 0;
    const replyFirstWidth = blockWidth - 158 - replyNameWidth - replyTimestampWidth;
    const replyLines = reply ? calculateTextLines(ctx, reply.text, 24, 'gg sans', contentWidth, replyFirstWidth) : [];
    let replyHeight = reply ? replyLines.length * 30 + 22 : 0;
    const rectangles = media.map((item, index) => {
        const ratio = Math.min(contentWidth / item.width, (index < replyMediaCount ? 240 : 360) / item.height);
        return { width: Math.round(item.width * ratio), height: Math.round(item.height * ratio), x: 0, y: 0 };
    });
    const replyRectangles = rectangles.slice(0, replyMediaCount);
    replyHeight += replyRectangles.reduce((sum, rect) => sum + rect.height + 24, 0);
    const messageRectangles = rectangles.slice(replyMediaCount);
    const mediaHeight = messageRectangles.reduce((sum, rect) => sum + rect.height + 24, 0);
    const totalHeight = reply ? replyHeight + 42 + messageLines.length * 42 + mediaHeight : calculation.totalHeight + mediaHeight;
    const height = reply ? Math.ceil(totalHeight + 80) : Math.max(cfg.height, Math.ceil(totalHeight + 120));
    if (height > 16384) throw new Error("This quote is too tall for one image. Choose a shorter message.");
    canvas.height = height;

    ctx.fillStyle = reply ? "#1c1d22" : "#000";
    ctx.fillRect(0, 0, cfg.width, height);

    if (!reply) {
        const avatar = await loadAvatar(payload.avatarUrl);
        ctx.drawImage(avatar, 0, (height - cfg.height) / 2, cfg.height, cfg.height);
        if (payload.grayscale) {
            ctx.globalCompositeOperation = 'saturation';
            ctx.fillStyle = '#fff';
            ctx.fillRect(0, 0, cfg.width, height);
            ctx.globalCompositeOperation = 'source-over';
        }
        const gradient = ctx.createLinearGradient(cfg.height - sp.gradientWidth, 0, cfg.height, 0);
        gradient.addColorStop(0, 'rgba(0, 0, 0, 0)');
        gradient.addColorStop(1, 'rgba(0, 0, 0, 1)');
        ctx.fillStyle = gradient;
        ctx.fillRect(cfg.height - sp.gradientWidth, 0, sp.gradientWidth, height);
    }

    ctx.save();
    ctx.beginPath();
    ctx.rect(areaX, 40, areaWidth, height - 80);
    ctx.clip();
    ctx.textAlign = "center";
    ctx.textBaseline = "top";
    const centerX = cfg.quoteAreaX + cfg.quoteAreaWidth / 2;
    ctx.fillStyle = "#fff";
    ctx.font = "300 " + calculation.fontSize + "px '" + quoteFont + "', sans-serif";
    let quoteY = (height - totalHeight) / 2;
    if (reply) {
        const x = blockX;
        const avatar = await loadAvatar(payload.avatarUrl);
        const replyAvatar = await loadAvatar(reply.avatarUrl);
        ctx.strokeStyle = '#4e5058'; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.moveTo(x + 42, quoteY + replyHeight - 8);
        ctx.lineTo(x + 42, quoteY + 24);
        ctx.quadraticCurveTo(x + 42, quoteY + 14, x + 52, quoteY + 14);
        ctx.lineTo(x + 92, quoteY + 14); ctx.stroke();
        ctx.save(); ctx.beginPath(); ctx.arc(x + 122, quoteY + 14, 14, 0, Math.PI * 2); ctx.clip();
        ctx.drawImage(replyAvatar, x + 108, quoteY, 28, 28); ctx.restore();
        ctx.textAlign = 'left';
        ctx.fillStyle = reply.color;
        ctx.font = "600 24px 'gg sans', sans-serif";
        ctx.fillText(reply.displayName, x + 144, quoteY, replyNameWidth);
        ctx.fillStyle = '#949ba4';
        ctx.font = "400 24px 'gg sans', sans-serif";
        if (reply.timestamp) ctx.fillText(reply.timestamp, x + 158 + replyNameWidth, quoteY, replyTimestampWidth - 18);
        ctx.fillStyle = '#b5bac1';
        replyLines.forEach((line, index) => ctx.fillText(line, index ? x + 108 : x + 158 + replyNameWidth + replyTimestampWidth, quoteY + index * 30, index ? contentWidth : replyFirstWidth));
        let replyMediaY = quoteY + replyLines.length * 30 + 12;
        for (const rect of replyRectangles) {
            rect.x = Math.round(x + 108);
            rect.y = Math.round(replyMediaY);
            replyMediaY += rect.height + 24;
        }
        quoteY += replyHeight;
        ctx.save(); ctx.beginPath(); ctx.arc(x + 42, quoteY + 42, 42, 0, Math.PI * 2); ctx.clip();
        ctx.drawImage(avatar, x, quoteY, 84, 84); ctx.restore();
        ctx.fillStyle = payload.authorColor || '#f2f3f5';
        ctx.font = "600 30px 'gg sans', sans-serif";
        const nameWidth = ctx.measureText(payload.displayName).width;
        ctx.fillText(payload.displayName, x + 108, quoteY, nameWidth);
        let headerX = x + 108 + nameWidth + 18;
        if (payload.isBot) {
            ctx.fillStyle = '#5865f2';
            ctx.fillRect(headerX, quoteY + 3, 60, 32);
            ctx.fillStyle = '#fff'; ctx.font = "600 22px 'gg sans', sans-serif";
            ctx.fillText('APP', headerX + 6, quoteY + 7, 48);
            headerX += 74;
        }
        ctx.fillStyle = '#949ba4'; ctx.font = "400 24px 'gg sans', sans-serif";
        ctx.fillText(payload.timestamp || '', headerX, quoteY + 9, blockX + blockWidth - headerX);
        quoteY += 42;
        ctx.fillStyle = '#dbdee1';
        ctx.font = "400 32px 'gg sans', sans-serif";
    }
    for (const line of messageLines) {
        ctx.fillText(line, reply ? blockX + 108 : centerX, quoteY, contentWidth);
        quoteY += reply ? 42 : calculation.lineHeight;
    }
    for (const rect of messageRectangles) {
        rect.x = Math.round(reply ? blockX + 108 : centerX - rect.width / 2);
        rect.y = Math.round(quoteY + 24);
        quoteY += rect.height + 24;
    }
    if (!reply) {
    ctx.font = "italic 300 " + calculation.authorFontSize + "px '" + quoteFont + "', sans-serif";
    const authorY = quoteY + sp.authorTop;
    ctx.fillText("- " + String(payload.displayName || "Unknown"), centerX, authorY, cfg.quoteAreaWidth);
    ctx.font = "300 " + calculation.usernameFontSize + "px '" + quoteFont + "', sans-serif";
    ctx.fillStyle = "#888";
    const usernameY = authorY + calculation.authorFontSize + sp.username;
    ctx.fillText(String(payload.username || "@unknown"), centerX, usernameY, cfg.quoteAreaWidth);
    }
    ctx.restore();

    if (payload.showWatermark && payload.watermark) {
        const watermarkText = String(payload.watermark).slice(0, 32);
        ctx.fillStyle = "#888";
        ctx.font = "300 " + fs.watermark + "px '" + quoteFont + "', sans-serif";
        ctx.textAlign = reply ? "left" : "right";
        ctx.textBaseline = "alphabetic";
        const watermarkX = reply ? blockX + 108 : cfg.width - sp.watermarkPadding;
        const watermarkY = reply ? quoteY + 24 : height - sp.watermarkPadding;
        ctx.fillText(watermarkText, watermarkX, watermarkY, reply ? contentWidth : cfg.quoteAreaWidth);
    }

    const dataUrl = media.length ? await exportMedia(canvas, media, rectangles, payload.renderId) : canvas.toDataURL("image/png");
    post({ type: "result", dataUrl, width: cfg.width, height, renderId: payload.renderId });
    } finally { for (const item of media) item.close(); }
}

render().catch(error => {
    post({
        type: "error",
        renderId: payload.renderId,
        message: String(error && error.message ? error.message : error),
    });
});
<\/script>
</body>
</html>`}function E(e){if(typeof e!=`string`||!e.startsWith(`data:`))return null;var t=e.indexOf(`,`);if(t<0)return null;var n=e.slice(5,t);return{body:e.slice(t+1),isBase64:n.includes(`;base64`),mime:(n.split(`;`)[0]||`image/png`).trim()||`image/png`}}function D(){try{var e=valenced.modules.finders.lookupModule(valenced.modules.finders.filters.withProps(`getAPIBaseURL`,`del`))[0]?.getAPIBaseURL?.();if(typeof e==`string`&&(e.startsWith(`//`)&&(e=`https:${e}`),e.startsWith(`http`)&&e.includes(`/api/`)))return e}catch{}return`https://discord.com/api/v9`}async function O(e,t,n){var r=E(t.dataUrl);if(!r?.isBase64||!r.body||![`image/png`,`image/gif`].includes(r.mime))throw Error(`Invalid rendered quote image.`);var i=r.mime===`image/gif`?`gif`:`png`;n=n.replace(/\.(png|gif)$/i,`.${i}`);var a=`revenge-next/quoter/${Date.now()}-${Math.random().toString(16).slice(2)}.${i}`,o=await valenced.discord.native.FileModule.writeFile(`cache`,a,r.body,`base64`),s=String(o).startsWith(`file://`)?String(o):`file://${o}`;try{var c=valenced.modules.finders.lookupModule(valenced.modules.finders.filters.withProps(`getToken`))[0]?.getToken?.();if(!c)throw Error(`Unable to resolve authorization token.`);var l=new FormData;l.append(`payload_json`,JSON.stringify({content:``,channel_id:e,type:0,sticker_ids:[],attachments:[{id:`0`,filename:n}],nonce:Date.now().toString()})),l.append(`files[0]`,{uri:s,type:r.mime,name:n});var u=new AbortController,d=setTimeout(function(){return u.abort()},6e4),f;try{f=await fetch(`${D()}/channels/${e}/messages`,{method:`POST`,headers:{Authorization:c},body:l,signal:u.signal})}catch(e){throw(e instanceof Error?e.name:void 0)===`AbortError`?/* @__PURE__ */ Error(`Upload timed out.`):e}finally{clearTimeout(d)}if(!f.ok){var p=await f.text().catch(function(){return``});throw console.error(`[Quoter] REST upload failed:`,f.status,p),Error(`Discord API returned ${f.status}`)}}finally{try{await valenced.discord.native.FileModule.removeFile(`cache`,a)}catch(e){console.warn(`[Quoter] Could not remove cached quote`,e)}}}var k=`Made with Valenced`,A={grayscale:!1,quotationMarks:!1,allowMedia:!1,allowReplies:!1,showWatermark:!1,watermark:k},j=A,M,N=!1,P=/* @__PURE__ */ new Set;function F(e){M=e}async function I(){var e=M.cache??await M.get();if(!e)throw Error(`Could not load Quoter settings.`);j={...A,...e},L()}function L(){for(var e of P)e()}function R(e){N=e,L()}function z(e){return P.add(e),function(){P.delete(e)}}function B(){return valenced.react.React.useSyncExternalStore(z,function(){return N})}function V(e){j={...j,...e},M.set(j,!0),L()}function H(){return{...valenced.react.React.useSyncExternalStore(z,function(){return j}),updateSettings:V}}H.subscribe=z;var U=`revenge-next.quoter.preview`;function W(){valenced.discord.actions.AlertActionCreators.dismissAlert(U)}function G(e){valenced.discord.actions.AlertActionCreators.openAlert(U,/*#__PURE__*/ t(K,{message:e}))}function K({message:e}){var{height:r}=valenced.react.ReactNative.useWindowDimensions(),i=H(),a=B(),[o]=valenced.react.React.useState(function(){var e=valenced.modules.finders.lookupModule(valenced.modules.finders.filters.withProps(`WebView`),{initialize:!1})[0]?.WebView;if(e)return e;var[,t]=valenced.modules.finders.lookupModule(valenced.modules.finders.filters.withName(`codegenNativeCommands`));if(t!==void 0)return valenced.modules.finders.lookupModule(valenced.modules.finders.filters.withDependencies([valenced.react.ReactModuleId,valenced.react.ReactNativeModuleId,valenced.react.ReactJSXRuntimeModuleId,t,null,null,null,null,null]).and(valenced.modules.finders.filters.withProps(`render`,`isFileUploadSupported`)))[0]}),[s,c]=valenced.react.React.useState(),[l,u]=valenced.react.React.useState(``),d=i.allowReplies&&!!m(e),[f,p]=valenced.react.React.useState(i.watermark);valenced.react.React.useEffect(function(){if(f!==i.watermark){var e=setTimeout(function(){return i.updateSettings({watermark:f})},500);return function(){return clearTimeout(e)}}},[f,i.watermark]);var{id:h,html:g}=valenced.react.React.useMemo(function(){var t=`${Date.now()}-${Math.random()}`;return{id:t,html:T({...S(e,i,d),renderId:t})}},[e,i.grayscale,i.showWatermark,i.watermark,i.quotationMarks,i.allowMedia,i.allowReplies,d]);valenced.react.React.useEffect(function(){u(``)},[h]);var _=s?.id===h?s.image:void 0,v=s?.id===h&&s.ready,x=async function(){if(_&&v&&a&&f===i.watermark){var t=y(e);if(!t)u(`Unable to resolve channel.`);else{W();try{await O(t,_,b(e)),valenced.discord.actions.ToastActionCreators.open(`QUOTER_SENT`,{text:`Quote sent.`})}catch(e){valenced.discord.actions.ToastActionCreators.open(`QUOTER_FAILED`,{text:`Failed to send quote: ${e instanceof Error?e.message:String(e)}`,variant:`critical`})}}}};return/*#__PURE__*/ t(valenced.discord.design.Design.AlertModal,{title:`Create Quote`,content:`Preview generated from selected message`,extraContent:/*#__PURE__*/ n(valenced.react.ReactNative.ScrollView,{style:{maxHeight:Math.max(160,r-280)},contentContainerStyle:{paddingTop:10,paddingBottom:4},children:[/*#__PURE__*/ n(valenced.react.ReactNative.View,{style:{width:`100%`,aspectRatio:_?_.width/_.height:2,maxHeight:260,alignSelf:`center`,borderRadius:14,overflow:`hidden`,backgroundColor:`#0f0f0f`,justifyContent:`center`,alignItems:`center`},children:[_?/*#__PURE__*/ t(valenced.react.ReactNative.Image,{source:{uri:_.dataUrl},resizeMode:`contain`,style:{width:`100%`,height:`100%`}}):o?null:/*#__PURE__*/ t(valenced.discord.design.Design.Text,{variant:`text-xs/medium`,children:`WebView unavailable. Cannot render quote.`}),o&&a&&!v&&!l&&/*#__PURE__*/ t(valenced.react.ReactNative.View,{pointerEvents:`none`,style:{position:`absolute`,left:0,top:0,right:0,bottom:0,alignItems:`center`,justifyContent:`center`},children:/*#__PURE__*/ t(valenced.react.ReactNative.View,{style:{backgroundColor:`#0009`,borderRadius:24,padding:8},children:/*#__PURE__*/ t(valenced.react.ReactNative.ActivityIndicator,{size:`small`,color:`#fff`,accessibilityLabel:`Preparing quote`})})})]}),o&&a?/*#__PURE__*/ t(o,{source:{html:g,baseUrl:d?`file:///android_asset/`:`https://localhost`},javaScriptEnabled:!0,onMessage:function(e){try{var t=JSON.parse(e.nativeEvent.data);if(t.renderId!==h)return;(t.type===`result`||t.type===`preview`)&&typeof t.dataUrl==`string`&&/^data:image\/(png|gif);base64,/.test(t.dataUrl)&&t.width>0&&t.height>0?c({id:h,ready:t.type===`result`,image:{dataUrl:t.dataUrl,width:t.width,height:t.height}}):t.type===`error`&&u(String(t.message))}catch{u(`Invalid renderer response.`)}},onError:function(){return u(`Could not load the quote renderer.`)},style:{width:1,height:1,opacity:0,position:`absolute`,left:-9999,top:-9999}},h):null,!!l&&/*#__PURE__*/ t(valenced.discord.design.Design.Text,{color:`text-feedback-critical`,children:l}),/*#__PURE__*/ t(valenced.discord.design.Design.TableSwitchRow,{label:`Quotation marks`,value:i.quotationMarks,onValueChange:function(e){return i.updateSettings({quotationMarks:e})}}),/*#__PURE__*/ t(valenced.discord.design.Design.TableSwitchRow,{label:`Grayscale`,value:i.grayscale,onValueChange:function(e){return i.updateSettings({grayscale:e})}}),/*#__PURE__*/ t(valenced.discord.design.Design.TableSwitchRow,{label:`Show Watermark`,value:i.showWatermark,onValueChange:function(e){return i.updateSettings({showWatermark:e})}}),i.showWatermark&&/*#__PURE__*/ t(valenced.discord.design.Design.TextInput,{label:`Watermark text`,value:f,maxLength:32,onChange:p})]}),actions:/*#__PURE__*/ n(valenced.react.React.Fragment,{children:[/*#__PURE__*/ t(valenced.discord.design.Design.AlertActionButton,{text:`Send`,variant:`primary`,disabled:!v||!a||f!==i.watermark,onPress:function(){x()}}),/*#__PURE__*/ t(valenced.discord.design.Design.AlertActionButton,{text:`Cancel`,variant:`secondary`,onPress:W})]})})}function q({api:{jsonStorage:e,plugin:r}}){F(e),e.use(),valenced.react.React.useEffect(function(){I().catch(function(e){return r.reportError(e)})},[r]);var i=H();return/*#__PURE__*/ t(valenced.react.ReactNative.ScrollView,{style:{flex:1},contentContainerStyle:{paddingBottom:38},children:/*#__PURE__*/ n(valenced.discord.design.Design.Stack,{style:{paddingVertical:24,paddingHorizontal:12},spacing:24,children:[/*#__PURE__*/ n(valenced.discord.design.Design.TableRowGroup,{title:`Quote content`,children:[/*#__PURE__*/ t(valenced.discord.design.Design.TableSwitchRow,{label:`Quotation marks`,subLabel:`Add " on both sides of the quote text.`,value:i.quotationMarks,onValueChange:function(e){return i.updateSettings({quotationMarks:e})}}),/*#__PURE__*/ t(valenced.discord.design.Design.TableSwitchRow,{label:`Allow media`,subLabel:`Include images and GIFs. Animated media exports as a GIF.`,value:i.allowMedia,onValueChange:function(e){return i.updateSettings({allowMedia:e})}}),/*#__PURE__*/ t(valenced.discord.design.Design.TableSwitchRow,{label:`Allow replies`,subLabel:`Include the referenced message when quoting replies.`,value:i.allowReplies,onValueChange:function(e){return i.updateSettings({allowReplies:e})}})]}),/*#__PURE__*/ n(valenced.discord.design.Design.TableRowGroup,{title:`Rendering`,children:[/*#__PURE__*/ t(valenced.discord.design.Design.TableSwitchRow,{label:`Grayscale`,subLabel:`Render the avatar in black and white`,icon:/*#__PURE__*/ t(valenced.discord.design.Design.TableRow.Icon,{source:valenced.assets.getAssetIdByName(`ImageIcon`)}),value:!!i.grayscale,onValueChange:function(e){return i.updateSettings({grayscale:e})}}),/*#__PURE__*/ t(valenced.discord.design.Design.TableSwitchRow,{label:`Show Watermark`,subLabel:`Draw watermark text in the bottom-right corner`,icon:/*#__PURE__*/ t(valenced.discord.design.Design.TableRow.Icon,{source:valenced.assets.getAssetIdByName(`PencilIcon`)}),value:!!i.showWatermark,onValueChange:function(e){return i.updateSettings({showWatermark:e})}})]}),i.showWatermark?/*#__PURE__*/ t(valenced.discord.design.Design.TextInput,{label:`Watermark Text`,description:`Only used when watermark is enabled. Max 32 characters.`,placeholder:k,size:`md`,maxLength:32,value:String(i.watermark??``),onChange:function(e){return i.updateSettings({watermark:e})}}):null]})})}return e.default=plugin({jsonStorage:{default:A},SettingsComponent:q,async start({cleanup:e,jsonStorage:n,plugin:r}){var a=!1;e(function(){a=!0,R(!1),W()}),r.startedLate&&r.requireReload(),F(n),await I(),!a&&(R(!0),e(valenced.modules.finders.getModules(valenced.modules.finders.filters.withName(`LongPressMessageActionSheet`),function(n){if(!a){var r=n;e(valenced.patcher.instead(r,`default`,function(e,n){var r=Reflect.apply(n,this,e),a=e[0].message;if(!a||!a.content&&!(j.allowMedia&&i(a).length))return r;var o=!1,s=function(e){if(!valenced.react.React.isValidElement(e))return e;var n=valenced.react.React.Children.toArray(e.props.children);if(!o&&e.props.hasIcons&&n.some(function(e){return valenced.react.React.isValidElement(e)&&typeof e.props.label==`string`})){var r=n.find(function(e){return valenced.react.React.isValidElement(e)&&typeof e.props.label==`string`});if(valenced.react.React.isValidElement(r)){o=!0;var i=r.type,c=valenced.react.React.isValidElement(r.props.icon)?valenced.react.React.cloneElement(r.props.icon,{IconComponent:valenced.utils.discord.lookupGeneratedIconComponent(`QuoteIcon`)}):void 0;return valenced.react.React.cloneElement(e,{},...n,/*#__PURE__*/ t(i,{label:`Quote`,icon:c,onPress:function(){valenced.discord.actions.ActionSheetActionCreators.hideAllActionSheets(),G(a)}},`quoter`))}}return valenced.react.React.cloneElement(e,{},valenced.react.React.Children.map(e.props.children,s))};return s(r)}))}},{returnNamespace:!0})))}}),e})({});